// Supabase Edge Function (Deno runtime)
// Deploy with: supabase functions deploy analyze-content
// Set the secret with: supabase secrets set GROQ_API_KEY=your_key_here

import { serve } from 'https://deno.land/std@0.224.0/http/server.ts';

const GROQ_API_KEY = Deno.env.get('GROQ_API_KEY')!;
const GROQ_URL = 'https://api.groq.com/openai/v1/chat/completions';

// Text/link analysis model — fast and reliable for structured JSON output.
const GROQ_MODEL = 'llama-3.3-70b-versatile';
// Vision model — qwen3.6-27b supports image inputs on this Groq account.
const GROQ_VISION_MODEL = 'qwen/qwen3.6-27b';

const RISK_THRESHOLD_TO_SKIP_CONTENT_SCAN = 60;

const TEXT_INSTRUCTIONS = `You are a content analysis engine for a misinformation-literacy tool.
Given a snippet of social media text, return ONLY a JSON object (no markdown, no prose) with this exact shape:

{
  "aiProbability": <integer 0-100, your best estimate that this text was AI-generated>,
  "biasFlags": [<short strings naming manipulation techniques present, e.g. "Urgency framing", "Fear appeal", "False dichotomy">],
  "reasoning": "<2-3 sentences in plain language explaining WHY, citing specific phrases or patterns in the text>"
}

Be honest about uncertainty. If the text is too short or ambiguous to judge confidently, say so in "reasoning" and keep aiProbability closer to 50.`;

const LINK_INSTRUCTIONS = `You are a link-safety analysis engine for a misinformation and scam-detection tool.
You will receive a URL (often copied from a Facebook post's Share menu). Judge it purely from its
structure — domain name, subdomain tricks, shorteners, path patterns. Return ONLY a JSON object
(no markdown, no prose) with this exact shape:

{
  "riskScore": <integer 0-100: how likely this link is a scam, phishing attempt, or otherwise unsafe/deceptive>,
  "riskFlags": [<short strings naming specific red flags, e.g. "Lookalike domain", "URL shortener", "Suspicious TLD", "Urgency bait in path">],
  "riskReasoning": "<1-2 sentences explaining the score>"
}

Guidance:
- Genuine facebook.com, fb.watch, or fb.com links with normal-looking paths are LOW risk.
- Watch for lookalike domains (e.g. "faceb00k.com", "facebook-security.com").
- URL shorteners raise risk moderately since the real destination is hidden, but aren't automatically scams.
- Watch for urgency/verification bait in the path (e.g. "/account-suspended", "/claim-prize").
- If the URL looks like a normal, well-formed Facebook permalink, say so and keep the score low.`;

const IMAGE_INSTRUCTIONS = `You are an image-authenticity analysis engine for a misinformation-literacy tool.
Look closely at the provided image and judge whether it is AI-generated/synthetic (including deepfakes
and AI-edited photos) versus a genuine, unedited photograph. Return ONLY a JSON object (no markdown,
no prose) with this exact shape:

{
  "aiProbability": <integer 0-100: how likely this image is AI-generated or synthetically manipulated>,
  "biasFlags": [<short strings naming specific visual tells you noticed, e.g. "Distorted hands", "Inconsistent lighting/shadows", "Unnaturally smooth skin texture", "Warped background text/objects", "Asymmetric or malformed facial features">],
  "reasoning": "<2-3 sentences explaining what visual evidence informed the score>"
}

Be honest about uncertainty — many real photos have imperfections, and many AI images now look highly
realistic. If you see no clear artifacts, say so and keep aiProbability closer to 30-40 rather than
claiming false confidence either way.`;

serve(async (req) => {
  const corsHeaders = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
    'Access-Control-Allow-Methods': 'POST, OPTIONS',
  };

  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders });
  }

  try {
    const { text, pageUrl, imageUrl } = await req.json();

    let result;

    if (imageUrl && typeof imageUrl === 'string') {
      result = await analyzeImage(imageUrl);
    } else if (text && typeof text === 'string') {
      const trimmed = text.trim();
      const isLink = /^https?:\/\/\S+$/i.test(trimmed);
      result = isLink ? await analyzeLink(trimmed) : await analyzeText(text, pageUrl);
    } else {
      return new Response(JSON.stringify({ error: 'Missing "text" or "imageUrl" field' }), {
        status: 400,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    return new Response(JSON.stringify(result), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  } catch (err) {
    return new Response(JSON.stringify({ error: String(err) }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }
});

async function analyzeText(text: string, pageUrl?: string) {
  const content = await callGroq(
    TEXT_INSTRUCTIONS,
    `Source URL: ${pageUrl ?? 'unknown'}\n\nText to analyze:\n"""${text}"""`
  );
  return {
    aiProbability: content.aiProbability ?? 50,
    biasFlags: content.biasFlags ?? [],
    reasoning: content.reasoning ?? 'No reasoning returned.',
    factCheckRefs: [],
  };
}

async function analyzeImage(imageUrl: string) {
  const result = await callGroqVision(IMAGE_INSTRUCTIONS, imageUrl);
  return {
    aiProbability: result.aiProbability ?? 50,
    biasFlags: result.biasFlags ?? [],
    reasoning: result.reasoning ?? 'No reasoning returned.',
    factCheckRefs: [],
  };
}

async function analyzeLink(url: string) {
  const linkCheck = await callGroq(LINK_INSTRUCTIONS, `Analyze this link:\n${url}`);
  const riskScore = linkCheck.riskScore ?? 50;
  const riskFlags: string[] = linkCheck.riskFlags ?? [];
  const riskReasoning = linkCheck.riskReasoning ?? 'No reasoning returned.';

  if (riskScore >= RISK_THRESHOLD_TO_SKIP_CONTENT_SCAN) {
    return {
      aiProbability: riskScore,
      biasFlags: riskFlags,
      reasoning: `⚠️ Link safety check: ${riskReasoning} Content was not scanned because this link looks risky.`,
      factCheckRefs: [],
    };
  }

  const pageText = await fetchPageText(url);

  if (!pageText) {
    return {
      aiProbability: riskScore,
      biasFlags: riskFlags,
      reasoning: `Link safety check: ${riskReasoning} Couldn't retrieve page content to analyze further (this is common for private or login-gated Facebook posts).`,
      factCheckRefs: [],
    };
  }

  const contentCheck = await callGroq(
    TEXT_INSTRUCTIONS,
    `Source URL: ${url}\n\nText to analyze:\n"""${pageText}"""`
  );

  return {
    aiProbability: contentCheck.aiProbability ?? 50,
    biasFlags: [...riskFlags, ...(contentCheck.biasFlags ?? [])],
    reasoning: `Link safety: ${riskReasoning} Content analysis: ${contentCheck.reasoning ?? 'No reasoning returned.'}`,
    factCheckRefs: [],
  };
}

async function fetchPageText(url: string): Promise<string | null> {
  try {
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 8000);

    const res = await fetch(url, {
      signal: controller.signal,
      headers: { 'User-Agent': 'Mozilla/5.0 (compatible; SpotTheBot/1.0; +https://example.com)' },
    });
    clearTimeout(timeout);

    if (!res.ok) return null;
    const html = await res.text();

    const ogTitle = html.match(/<meta[^>]+property=["']og:title["'][^>]+content=["']([^"']+)["']/i)?.[1];
    const ogDescription = html.match(/<meta[^>]+property=["']og:description["'][^>]+content=["']([^"']+)["']/i)?.[1];
    const titleTag = html.match(/<title>([^<]+)<\/title>/i)?.[1];

    const parts = [ogTitle, ogDescription, titleTag].filter(Boolean);
    return parts.length ? parts.join('\n\n') : null;
  } catch {
    return null;
  }
}

async function callGroq(systemPrompt: string, userContent: string): Promise<any> {
  const res = await fetch(GROQ_URL, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${GROQ_API_KEY}` },
    body: JSON.stringify({
      model: GROQ_MODEL,
      temperature: 0.2,
      response_format: { type: 'json_object' },
      messages: [
        { role: 'system', content: systemPrompt },
        { role: 'user', content: userContent },
      ],
    }),
  });

  if (!res.ok) {
    const errText = await res.text();
    throw new Error(`Groq API error (${res.status}): ${errText}`);
  }

  const data = await res.json();
  const rawText = data.choices?.[0]?.message?.content ?? '{}';
  try {
    return JSON.parse(rawText);
  } catch {
    return {};
  }
}

// Vision variant — sends the image URL using the multimodal message format.
// Uses qwen/qwen3.6-27b which supports image inputs on this Groq account.
// Falls back to URL-only text analysis if the vision call fails.
async function callGroqVision(systemPrompt: string, imageUrl: string): Promise<any> {
  try {
    const res = await fetch(GROQ_URL, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${GROQ_API_KEY}` },
      body: JSON.stringify({
        model: GROQ_VISION_MODEL,
        temperature: 0.2,
        response_format: { type: 'json_object' },
        messages: [
          { role: 'system', content: systemPrompt },
          {
            role: 'user',
            content: [
              { type: 'text', text: 'Analyze this image.' },
              { type: 'image_url', image_url: { url: imageUrl } },
            ],
          },
        ],
      }),
    });

    if (!res.ok) {
      const errText = await res.text();
      throw new Error(`Groq vision API error (${res.status}): ${errText}`);
    }

    const data = await res.json();
    const rawText = data.choices?.[0]?.message?.content ?? '{}';
    try {
      return JSON.parse(rawText);
    } catch {
      return {};
    }
  } catch (err) {
    // Vision call failed — fall back to analyzing the URL as text.
    console.warn('Vision model failed, falling back to URL text analysis:', err);
    return callGroq(
      systemPrompt,
      `The image could not be analyzed directly. Analyze this image URL based on its structure and domain:\n${imageUrl}`
    );
  }
}
