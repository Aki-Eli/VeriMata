import React from 'react';
import ReactDOM from 'react-dom/client';
import NutritionCard, { AnalysisResult } from '../../components/NutritionCard';

export default defineContentScript({
  matches: ['<all_urls>'],
  main(ctx) {
    // Guard against double-initialisation when the script is re-injected
    // on repeated right-clicks. The flag lives on the window object which
    // persists across injections in the same tab.
    const win = window as any;
    if (win.__stb_initialized) {
      console.log('[VeriMata] Content script already initialized, skipping');
      return;
    }
    win.__stb_initialized = true;

    let activeUi: Awaited<ReturnType<typeof createOverlayUi>> | null = null;

    let lastRightClickTarget: Element | null = null;
    document.addEventListener(
      'contextmenu',
      (e) => {
        lastRightClickTarget = e.target as Element;
      },
      true
    );

    // Single listener handles all message types — two separate listeners
    // caused both to fire for every message, creating duplicate cards.
    browser.runtime.onMessage.addListener((message) => {
      if (message.type === 'ANALYZE_IMAGE' || message.type === 'ANALYZE_VIDEO') {
        // Remove existing card immediately before starting new analysis
        activeUi?.remove();
        activeUi = null;
        const mediaUrl = message.type === 'ANALYZE_IMAGE' ? message.imageUrl : message.videoUrl;
        handleAnalyzeMediaRequest(ctx, mediaUrl, (ui) => {
          activeUi = ui;
        });
        return;
      }

      if (message.type === 'ANALYZE_SELECTION') {
        // Remove existing card immediately before starting new analysis
        activeUi?.remove();
        activeUi = null;

        const selection = window.getSelection();
        const hasSelection = !!selection && selection.toString().trim().length > 0;
        const startNode = hasSelection
          ? selection!.getRangeAt(0).startContainer
          : lastRightClickTarget;

        const postUrl = findPostPermalink(startNode) ?? message.pageUrl;
        const textToAnalyze = hasSelection ? message.text : postUrl;

        handleAnalyzeRequest(ctx, textToAnalyze, postUrl, (ui) => {
          activeUi = ui;
        });
      }
    });
  },
});

async function handleAnalyzeRequest(
  ctx: any,
  text: string,
  pageUrl: string,
  onMount: (ui: any) => void
) {
  const isLink = /^https?:\/\/\S+$/i.test(text.trim());
  const ui = await createOverlayUi(ctx, { status: 'loading' }, {
    postUrl: pageUrl,
    snippet: text,
  }, text, isLink ? 'link' : 'text');
  ui.mount();
  onMount(ui);

  const response = await browser.runtime.sendMessage({
    type: 'REQUEST_ANALYSIS',
    text,
    pageUrl,
  });

  if (response?.ok) {
    ui.update({ status: 'done', data: response.result as AnalysisResult });
  } else {
    ui.update({ status: 'error', message: response?.error ?? 'Unknown error' });
  }
}

async function handleAnalyzeMediaRequest(
  ctx: any,
  mediaUrl: string,
  onMount: (ui: any) => void
) {
  if (mediaUrl.startsWith('blob:')) {
    // Facebook often streams video through the MediaSource Extensions API,
    // so the <video> element's "src" is a local blob: URL, not a real,
    // fetchable link — there's no exact external URL to give you here.
    // (Right-clicking directly on a still photo doesn't have this problem.)
    const ui = await createOverlayUi(ctx, {
      status: 'error',
      message:
        "This video is playing from an in-browser stream (blob: URL), so there's no direct file link Spot the Bot can capture or analyze.",
    });
    ui.mount();
    onMount(ui);
    return;
  }

  // The whole point of right-clicking a specific photo/video is that
  // `mediaUrl` (from Chrome's context-menu `srcUrl`) IS the exact file —
  // not Facebook's SPA address bar, which stays "facebook.com/..." no
  // matter which post you're looking at. So THAT'S what gets saved as
  // the flaggable link, not window.location.href.
  const ui = await createOverlayUi(ctx, { status: 'loading' }, {
    postUrl: mediaUrl,
    snippet: mediaUrl,
  }, mediaUrl, 'image');
  ui.mount();
  onMount(ui);

  const response = await browser.runtime.sendMessage({
    type: 'REQUEST_ANALYSIS',
    imageUrl: mediaUrl,
    pageUrl: window.location.href,
  });

  if (response?.ok) {
    ui.update({ status: 'done', data: response.result as AnalysisResult });
  } else {
    ui.update({ status: 'error', message: response?.error ?? 'Unknown error' });
  }
}

// Creates a shadow-DOM-isolated React root, fixed-positioned on top of
// the page ('modal' position guarantees visibility regardless of where on
// Facebook's DOM the trigger happened).
async function createOverlayUi(
  ctx: any,
  initialState: { status: 'loading' } | { status: 'done'; data: AnalysisResult } | { status: 'error'; message: string },
  flaggable?: { postUrl: string; snippet: string },
  analyzedUrl?: string,
  contentType?: 'text' | 'link' | 'image'
) {
  let root: ReactDOM.Root | null = null;
  let currentState = initialState;
  let flagStatus: 'idle' | 'opening' | 'flagged' | 'error' = 'idle';
  let flagCount = 0;

  const ui = await createShadowRootUi(ctx, {
    name: 'spot-the-bot-overlay',
    position: 'modal',
    zIndex: 2147483647,
    onMount: (container, _shadow, shadowHost) => {
      // 'modal' positioning makes WXT apply `position: fixed` to the
      // shadowHost itself — the actual element sitting in Facebook's own
      // DOM (outside our shadow root) — sized/centered to the viewport so
      // the card can be placed anywhere on screen. That host element,
      // not just our content inside it, is what was swallowing clicks on
      // comment/share/react buttons underneath it, since it still
      // physically covers that part of the page even where there's
      // nothing visible.
      //
      // Making the host click-through lets those clicks fall through to
      // Facebook. NutritionCard's own `pointerEvents: 'auto'` on the
      // card element re-enables clicks for just the card (pointer-events
      // inherits from the host into the shadow tree the same way it
      // inherits from a normal parent, so an explicit 'auto' on a
      // descendant overrides the inherited 'none').
      shadowHost.style.pointerEvents = 'none';
      container.style.pointerEvents = 'none';

      root = ReactDOM.createRoot(container);
      render();
    },
    onRemove: () => {
      root?.unmount();
      root = null;
    },
  });

  let flagError: string | null = null;

  // Just open the flags page on the website, passing the post URL as a
  // query param — same pattern as "Full Deep Analysis" opening the analyzer.
  // No DB write happens here; the website handles everything on submit.
  async function handleFlag() {
    if (currentState.status !== 'done' || !flaggable) return;
    if (flagStatus !== 'idle' && flagStatus !== 'error') return;

    flagStatus = 'opening';
    flagError = null;
    render();

    const flagUrl = `https://veri-mata.vercel.app/dashboard/flags?flag=${encodeURIComponent(flaggable.postUrl)}&from=extension`;
    browser.runtime.sendMessage({ type: 'OPEN_WEB_APP', url: flagUrl });

    flagStatus = 'flagged';
    render();
  }

  function render() {
    root?.render(
      <NutritionCard
        state={currentState}
        onClose={() => ui.remove()}
        onFlag={flaggable ? handleFlag : undefined}
        flagStatus={flagStatus}
        flagCount={flagCount}
        flagError={flagError}
        analyzedUrl={analyzedUrl}
        contentType={contentType}
      />
    );
  }

  return {
    mount: () => ui.mount(),
    remove: () => ui.remove(),
    update: async (state: typeof initialState) => {
      currentState = state;
      render();
      // When analysis completes, check how many times this URL has been flagged
      if (state.status === 'done' && flaggable) {
        const res = await browser.runtime.sendMessage({
          type: 'GET_FLAG_COUNT',
          postUrl: flaggable.postUrl,
        });
        if (res?.ok && res.count > 0) {
          flagCount = res.count;
          render();
        }
      }
    },
  };
}

// Facebook posts don't have their own URL in the address bar — it's a
// single-page app. But each post embeds its real permalink on the
// timestamp link (e.g. "8h", "2d") or media links. We walk up from
// wherever the user right-clicked (or their text selection) to find
// THAT post's own container, then dig out that link — and only that
// link. Facebook marks each individual post/story with role="article",
// so that's the boundary we stop at. If we didn't stop there, keeping
// on climbing eventually reaches a shared ancestor (the whole feed),
// whose querySelectorAll match would return links belonging to OTHER
// posts too — not the one the user actually clicked on.
const PERMALINK_SELECTOR =
  'a[href*="/posts/"], a[href*="/videos/"], a[href*="story_fbid"], a[href*="/photo/"]';

function findPostPermalink(startNode: Node | null): string | null {
  let el: Element | null =
    startNode instanceof Element ? startNode : startNode?.parentElement ?? null;

  // Step 1: climb up until we land on the post's own container.
  const postContainer = el?.closest('[role="article"]') ?? null;

  if (postContainer) {
    // Step 2: search ONLY inside that container — never outside it.
    return extractExactUrl(postContainer);
  }

  // Fallback for markup that doesn't use role="article" (e.g. some
  // group/marketplace layouts): climb a bounded number of steps, but
  // stop immediately at the first container that has something usable
  // rather than continuing to search wider ancestors.
  el = startNode instanceof Element ? startNode : startNode?.parentElement ?? null;
  for (let i = 0; i < 15 && el; i++) {
    // Bail out before reaching feed-level containers that hold many posts.
    if (el.getAttribute('role') === 'feed') break;

    const found = extractExactUrl(el);
    if (found) return found;

    el = el.parentElement;
  }
  return null;
}

// Given a post's container, find the most exact URL available — in order
// of preference:
//   1. The actual photo file Facebook served. Facebook tags real content
//      photos with data-visualcompletion="media-vc-image" (as opposed to
//      profile pictures/reaction icons, which don't carry that attribute),
//      so this reliably skips avatars.
//   2. The <video> element's real network src, when it has one (Facebook
//      sometimes streams via MediaSource/blob: URLs instead — those aren't
//      usable external links, so we deliberately skip them here).
//   3. Facebook's own permalink to the post/photo/video, as a last resort
//      when there's no actual media file to point to (e.g. a text-only
//      post). We prefer the real media link over this because the
//      permalink is still just a facebook.com/... address — not the exact
//      file — and the whole point here is the exact file.
function extractExactUrl(container: Element): string | null {
  const contentImage = container.querySelector(
    'img[data-visualcompletion="media-vc-image"]'
  ) as HTMLImageElement | null;
  if (contentImage?.src) return contentImage.src;

  const video = container.querySelector('video') as HTMLVideoElement | null;
  const videoSrc = video?.currentSrc || video?.src;
  if (videoSrc && !videoSrc.startsWith('blob:')) return videoSrc;

  const link = container.querySelector(PERMALINK_SELECTOR) as HTMLAnchorElement | null;
  if (link?.href) return link.href;

  return null;
}
