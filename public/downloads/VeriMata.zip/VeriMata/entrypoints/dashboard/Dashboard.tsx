import React, { useCallback, useEffect, useState } from 'react';
import { supabase, type FlaggedPost } from '../../lib/supabase';

type LoadState =
  | { status: 'loading' }
  | { status: 'error'; message: string }
  | { status: 'loaded'; posts: FlaggedPost[] };

export default function Dashboard() {
  const [state, setState] = useState<LoadState>({ status: 'loading' });

  const load = useCallback(async () => {
    setState({ status: 'loading' });

    const { data, error } = await supabase
      .from('flags')
      .select('*')
      .order('created_at', { ascending: false })
      .limit(200);

    if (error) {
      setState({ status: 'error', message: error.message });
      return;
    }

    setState({ status: 'loaded', posts: (data ?? []) as FlaggedPost[] });
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  return (
    <div style={styles.page}>
      <header style={styles.header}>
        <div>
          <h1 style={styles.title}>Spot the Bot — Flagged Posts</h1>
          <p style={styles.subtitle}>
            Everything the community has flagged as suspicious, newest first.
          </p>
        </div>
        <button style={styles.refreshBtn} onClick={load}>
          Refresh
        </button>
      </header>

      <main style={styles.main}>
        {state.status === 'loading' && <p style={styles.muted}>Loading…</p>}

        {state.status === 'error' && (
          <div style={styles.errorBox}>
            <p style={{ margin: 0 }}>Couldn't load flagged posts: {state.message}</p>
            <p style={styles.mutedSmall}>
              If this is a fresh setup, make sure the <code>flags</code> table exists
              (see <code>supabase/migrations/0001_create_flags.sql</code>) and that its
              row-level security policies allow anon <code>select</code>.
            </p>
          </div>
        )}

        {state.status === 'loaded' && state.posts.length === 0 && (
          <p style={styles.muted}>
            No posts have been flagged yet. Flag one from the extension and it'll show up here.
          </p>
        )}

        {state.status === 'loaded' &&
          state.posts.map((post, i) => <FlaggedPostCard key={post.id} post={post} isNewest={i === 0} />)}
      </main>
    </div>
  );
}

function FlaggedPostCard({ post, isNewest }: { post: FlaggedPost; isNewest: boolean }) {
  const isRisky = post.ai_probability >= 60;
  const justNow = isNewest && Date.now() - new Date(post.created_at).getTime() < 60_000;

  return (
    <div style={{ ...styles.card, ...(justNow ? styles.cardHighlight : {}) }}>
      {justNow && <div style={styles.newBadge}>Just flagged</div>}

      <div style={styles.cardTop}>
        <span style={styles.timestamp}>{formatRelativeTime(post.created_at)}</span>
        <span style={{ ...styles.score, color: isRisky ? '#b91c1c' : '#15803d' }}>
          {post.ai_probability}%
        </span>
      </div>

      {post.bias_flags.length > 0 && (
        <div style={styles.flagRow}>
          {post.bias_flags.map((flag) => (
            <span key={flag} style={styles.flagChip}>
              {flag}
            </span>
          ))}
        </div>
      )}

      {post.reasoning && <p style={styles.reasoning}>{post.reasoning}</p>}

      {post.snippet && <p style={styles.snippet}>{truncate(post.snippet, 220)}</p>}

      <a href={post.post_url} target="_blank" rel="noreferrer" style={styles.link}>
        View original post ↗
      </a>
    </div>
  );
}

function truncate(text: string, max: number): string {
  return text.length > max ? `${text.slice(0, max)}…` : text;
}

function formatRelativeTime(iso: string): string {
  const diffMs = Date.now() - new Date(iso).getTime();
  const minutes = Math.floor(diffMs / 60_000);
  if (minutes < 1) return 'just now';
  if (minutes < 60) return `${minutes}m ago`;
  const hours = Math.floor(minutes / 60);
  if (hours < 24) return `${hours}h ago`;
  const days = Math.floor(hours / 24);
  return `${days}d ago`;
}

const styles: Record<string, React.CSSProperties> = {
  page: { minHeight: '100vh', color: '#111827' },
  header: {
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    padding: '20px 24px',
    background: '#111827',
    color: '#fff',
  },
  title: { margin: '0 0 4px 0', fontSize: 18 },
  subtitle: { margin: 0, fontSize: 13, color: '#9ca3af' },
  refreshBtn: {
    padding: '8px 14px',
    borderRadius: 6,
    border: '1px solid #374151',
    background: '#1f2937',
    color: '#fff',
    fontSize: 13,
    cursor: 'pointer',
  },
  main: {
    maxWidth: 720,
    margin: '0 auto',
    padding: '24px 16px 48px',
    display: 'flex',
    flexDirection: 'column',
    gap: 12,
  },
  muted: { color: '#6b7280', fontSize: 14 },
  mutedSmall: { color: '#6b7280', fontSize: 12, marginTop: 6 },
  errorBox: {
    background: '#fef2f2',
    border: '1px solid #fca5a5',
    color: '#b91c1c',
    borderRadius: 8,
    padding: 12,
    fontSize: 13,
  },
  card: {
    background: '#fff',
    border: '1px solid #e5e7eb',
    borderRadius: 10,
    padding: 14,
    position: 'relative',
  },
  cardHighlight: { border: '1px solid #16a34a', boxShadow: '0 0 0 3px rgba(22,163,74,0.15)' },
  newBadge: {
    position: 'absolute',
    top: -10,
    left: 14,
    background: '#16a34a',
    color: '#fff',
    fontSize: 10,
    fontWeight: 700,
    padding: '2px 8px',
    borderRadius: 999,
    letterSpacing: 0.3,
  },
  cardTop: { display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 8 },
  timestamp: { fontSize: 12, color: '#6b7280' },
  score: { fontSize: 15, fontWeight: 700 },
  flagRow: { display: 'flex', flexWrap: 'wrap', gap: 4, marginBottom: 8 },
  flagChip: {
    background: '#fef3c7',
    color: '#92400e',
    padding: '2px 8px',
    borderRadius: 999,
    fontSize: 11,
  },
  reasoning: { fontSize: 13, color: '#374151', lineHeight: 1.4, margin: '0 0 6px 0' },
  snippet: {
    fontSize: 12,
    color: '#6b7280',
    lineHeight: 1.4,
    margin: '0 0 8px 0',
    background: '#f9fafb',
    padding: 8,
    borderRadius: 6,
    fontStyle: 'italic',
  },
  link: { fontSize: 12, color: '#2563eb', textDecoration: 'none' },
};
