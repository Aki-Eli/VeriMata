-- Migration: drop dependency on flags table, flag_reports is now standalone
-- Run this in your Supabase SQL Editor

-- 1. Create flag_reports as a standalone table (no FK to flags)
CREATE TABLE IF NOT EXISTS public.flag_reports (
  id         uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  created_at timestamptz NOT NULL DEFAULT now(),
  post_url   text NOT NULL,
  user_id    uuid,
  user_email text,
  reason     text NOT NULL,
  category   text
);

CREATE INDEX IF NOT EXISTS flag_reports_post_url_idx ON public.flag_reports (post_url);
CREATE INDEX IF NOT EXISTS flag_reports_created_at_idx ON public.flag_reports (created_at DESC);

ALTER TABLE public.flag_reports ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can insert flag_reports"
  ON public.flag_reports FOR INSERT TO anon, authenticated WITH CHECK (true);

CREATE POLICY "Anyone can read flag_reports"
  ON public.flag_reports FOR SELECT TO anon, authenticated USING (true);
