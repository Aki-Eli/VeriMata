# Spot the Bot — Facebook Overlay Extension (v1 MVP)

## What this does
Right-click selected text on Facebook → sends it through a Supabase Edge Function
to Gemini → shows a "Digital Nutrition Label" card with an AI-probability score,
bias flags, and a plain-language explanation.

## Project layout
```
entrypoints/
  background.ts              # registers context menu, proxies analysis calls, saves flags
  facebook.content/index.tsx # content script: injects the overlay on facebook.com
  dashboard/                  # standalone page listing every flagged post
components/
  NutritionCard.tsx           # the overlay card UI
lib/
  supabase.ts                  # shared Supabase client (used by background.ts + dashboard)
supabase/functions/
  analyze-content/index.ts    # Edge Function that calls Gemini (key stays server-side)
supabase/migrations/
  0001_create_flags.sql       # the `flags` table + RLS policies
wxt.config.ts                 # manifest permissions, host_permissions = facebook.com only
```

## Flagging a post
Clicking "Flag as suspicious" on the overlay saves that post (URL, snippet,
score, bias flags, reasoning) to the `flags` table in Supabase, then opens
the dashboard page — bundled with the extension itself, no external hosting
needed — in a new tab so you can see it land there. Before this works you
need to run the migration below.

## Setup (run these on your own machine — this sandbox has no network access)

### 1. Install dependencies
```bash
npm install
```

### 2. Run in dev mode (loads into a real Chrome instance with HMR)
```bash
npm run dev
```
WXT will open a Chrome window with the extension pre-loaded. Go to facebook.com,
highlight some post text, right-click → "Analyze with Spot the Bot".

### 3. Set up the Supabase side
```bash
npx supabase init
npx supabase link --project-ref YOUR_PROJECT_REF
npx supabase db push                          # creates the `flags` table (see migrations/)
npx supabase functions new analyze-content     # then replace with the file in supabase/functions/
npx supabase secrets set GEMINI_API_KEY=your_key_here
npx supabase functions deploy analyze-content
```
No project yet, or don't want the CLI? Paste the contents of
`supabase/migrations/0001_create_flags.sql` into the SQL Editor in the
Supabase dashboard instead — that's all `db push` does here.

Get a Gemini API key from https://aistudio.google.com/apikey (free tier available).

### 4. Wire up the real endpoint
In `entrypoints/background.ts`, replace:
```ts
const SUPABASE_FUNCTION_URL = 'https://YOUR_PROJECT_REF.supabase.co/functions/v1/analyze-content';
```
with your actual project's function URL (shown after `supabase functions deploy`).

### 5. Build for production
```bash
npm run build   # outputs to .output/chrome-mv3/
npm run zip     # packages it for Chrome Web Store submission
```

## Known gaps / things to build next (intentionally left out of v1)
- **Confirm/Dispute still don't write anywhere** — only "Flag as suspicious"
  is wired to Supabase so far. Same pattern as `onFlag` in `background.ts`
  (a `FLAG_POST`-style message + a table) would work for these too.
- **Dashboard is public read** — the `flags` table's RLS policy lets anyone
  with the anon key read it, same as anyone with the extension installed.
  There's no login. Add Supabase Auth if you want it restricted to
  moderators only.
- **No auth on the analyze endpoint** — anyone can call your Edge Function right now. Add Supabase Auth
  or at least a rate limit before this goes public.
- **Streamed video has no exact URL** — if Facebook is playing a video via
  MediaSource Extensions (a `blob:` src), there's no real external file link
  to capture, so "Analyze video" shows an explanatory error instead of a
  broken link. Right-clicking a still photo doesn't have this problem.
- **Facebook DOM is unstable** — the anchor-positioning logic in
  `getAnchorElement()` is best-effort. Expect to revisit selector logic as
  Facebook changes its markup.
- **Gemini JSON reliability** — even with `responseMimeType: "application/json"`,
  validate the shape server-side before trusting it (there's a bare-bones
  fallback in the Edge Function now, but consider a schema validator like Zod).

## Why this structure
- **Background script owns the network call**, never the content script — this
  keeps your Gemini key out of the extension bundle, which is fully inspectable
  by anyone who installs it.
- **Shadow DOM for the overlay** — `cssInjectionMode: 'ui'` + `createShadowRootUi`
  means Facebook's global CSS can't override your card's styles, and your styles
  can't leak into Facebook's page either.
- **Facebook-only host_permissions** — narrower permissions = faster review if/when
  you submit to the Chrome Web Store, and fewer DOM edge cases to handle in v1.
