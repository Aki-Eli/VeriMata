import { defineConfig } from 'wxt';

export default defineConfig({
  modules: ['@wxt-dev/module-react'],
  manifestVersion: 3,
  manifest: {
    name: 'VeriMata - AI Content Detector',
    description: 'Detects AI-generated content, bias, and misinformation. Sign in with your VeriMata account to use.',
    version: '0.2.0',
    permissions: ['contextMenus', 'storage', 'activeTab', 'scripting', 'tabs'],
    host_permissions: [
      '<all_urls>',
      'https://*.supabase.co/*',
      'https://veri-mata.vercel.app/*',
      'https://generativelanguage.googleapis.com/*',
      'https://serpapi.com/*',
      'https://image.pollinations.ai/*',
    ],
    background: {
      service_worker: 'background.js',
    },
    action: {
      default_title: 'Spot the Bot',
      default_popup: 'popup.html',
      default_icon: {
        '16': 'images/logo.png',
        '48': 'images/logo.png',
        '128': 'images/logo.png',
      },
    },
    icons: {
      '16': 'images/logo.png',
      '48': 'images/logo.png',
      '128': 'images/logo.png',
    },
  },
});
