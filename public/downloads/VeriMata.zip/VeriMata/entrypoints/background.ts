// ── Config ─────────────────────────────────────────────────────────────────
const SUPABASE_URL     = import.meta.env.VITE_SUPABASE_URL as string;
const SUPABASE_ANON    = import.meta.env.VITE_SUPABASE_ANON_KEY as string;
const SUPABASE_SERVICE = import.meta.env.VITE_SUPABASE_SERVICE_ROLE_KEY as string;
const SERP_KEY         = import.meta.env.VITE_SERP_API_KEY as string;
const GEMINI_MODEL     = 'gemini-3.5-flash-lite';
const WEBSITE_URL      = 'https://veri-mata.vercel.app';

// Gemini key is NOT stored in the bundle — fetched from Vercel on first use.
// Cached in chrome.storage.session so it survives service worker restarts
// without needing another round-trip to Vercel every time Chrome wakes the SW.
let _geminiKeyMemory: string | null = null;
let _geminiKeyFetching: Promise<string> | null = null;

async function getGeminiKey(): Promise<string> {
  // 1. In-memory cache (fastest — same SW instance)
  if (_geminiKeyMemory) return _geminiKeyMemory;

  // 2. session storage cache (survives SW restart within same browser session)
  try {
    const stored = await chrome.storage.session.get('gemini_key');
    if (stored?.gemini_key) {
      _geminiKeyMemory = stored.gemini_key;
      return _geminiKeyMemory!;
    }
  } catch { /* session storage not available, fall through */ }

  // 3. Deduplicate concurrent fetches
  if (_geminiKeyFetching) return _geminiKeyFetching;

  _geminiKeyFetching = (async () => {
    const stored = await chrome.storage.local.get(['sb_full_session', 'sb_session']);
    const token = stored?.sb_full_session?.access_token ?? stored?.sb_session?.access_token;
    if (!token) throw new Error('Not signed in — cannot fetch API key');

    const res = await fetch(`${WEBSITE_URL}/api/get-gemini-key`, {
      headers: { Authorization: `Bearer ${token}` },
    });
    if (!res.ok) throw new Error(`Key fetch failed: ${res.status}`);
    const { key } = await res.json();
    if (!key) throw new Error('Empty key returned from server');

    _geminiKeyMemory = key;
    // Persist to session storage so next SW wake skips the fetch
    try { await chrome.storage.session.set({ gemini_key: key }); } catch { /* non-fatal */ }
    return key;
  })();

  try {
    return await _geminiKeyFetching;
  } finally {
    _geminiKeyFetching = null;
  }
}

const TEXT_POOL_TARGET  = 10;
const IMAGE_POOL_TARGET = 10;
const REFILL_THRESHOLD  = 7;

const TOPICS = [
  'a cozy coffee shop morning', 'hiking in the mountains', 'a street market in Asia',
  'a dog playing in the park', 'a sunset at the beach', 'a rainy city street',
  'a home-cooked meal', 'a child blowing out birthday candles', 'an old library',
  'a garden in spring', 'a busy train station', 'a snowy mountain village',
  'a tropical beach resort', 'a farmers market', 'a birthday party',
  'a morning run in the city', 'a cat sitting on a windowsill', 'a bookshop',
  'a rooftop view at night', 'a picnic in the park',
];

// ── Analysis prompts ───────────────────────────────────────────────────────

// PASS 1 — Deep analysis saved to DB
const DEEP_TEXT_PROMPT = `You are a forensic content analyst. Perform an exhaustive, fact-based analysis of the following text.
Do NOT introduce political, cultural, or ideological bias. Be honest about uncertainty.

Return ONLY raw JSON (no markdown, no code fences):
{
  "aiProbability": <integer 0-100, likelihood this text is AI-generated>,
  "confidence": "<'high' | 'medium' | 'low'>",
  "verdict": "<one clear sentence verdict>",
  "originAssessment": "<detailed paragraph: sentence structure, vocabulary, syntactic patterns, emotional authenticity — what makes this feel human or AI>",
  "rhetoricalTechniques": "<detailed paragraph: every persuasion or manipulation technique — fear appeal, false urgency, emotional loading, false dichotomy. Quote directly>",
  "factualityScore": <integer 0-100, how likely the claims in this text are factual. 100 = all claims appear well-supported, 0 = all claims appear fabricated or unverifiable. Use 50 if too ambiguous>,
  "factualClaims": [
    {
      "claim": "<exact quoted or paraphrased claim from the text>",
      "verdict": "<'likely true' | 'likely false' | 'unverifiable' | 'misleading'>",
      "evidence": "<2-3 sentences: specific reasoning or known facts that support this verdict. Cite what is known, what is not, and why>",
      "confidence": "<'high' | 'medium' | 'low'>"
    }
  ],
  "crossChecks": [
    {"signal": "<specific phrase or pattern>", "interpretation": "<what this tells us>", "weight": "<'strong' | 'moderate' | 'weak'>"}
  ],
  "overallVerdict": "<detailed paragraph: final credibility and factuality assessment with specific reasoning>"
}`;

const DEEP_LINK_PROMPT = `You are a forensic URL safety analyst. Perform an exhaustive, fact-based analysis of this URL.
Be honest — do not flag legitimate URLs without evidence.

Return ONLY raw JSON (no markdown, no code fences):
{
  "aiProbability": <integer 0-100, overall risk score>,
  "confidence": "<'high' | 'medium' | 'low'>",
  "verdict": "<one clear sentence verdict>",
  "factualityScore": <integer 0-100, how trustworthy this URL appears based on its structure. 100 = appears fully legitimate>,
  "factualClaims": [
    {
      "claim": "<specific structural claim, e.g. 'Domain resembles facebook.com'>",
      "verdict": "<'likely true' | 'likely false' | 'unverifiable' | 'misleading'>",
      "evidence": "<specific structural evidence supporting this assessment>",
      "confidence": "<'high' | 'medium' | 'low'>"
    }
  ],
  "domainAnalysis": "<detailed paragraph: domain breakdown, TLD, lookalike patterns>",
  "pathAnalysis": "<detailed paragraph: path and query params analysis>",
  "trustSignals": "<detailed paragraph: legitimacy indicators for and against>",
  "crossChecks": [
    {"signal": "<specific URL element>", "interpretation": "<what this tells us>", "weight": "<'strong' | 'moderate' | 'weak'>"}
  ],
  "overallVerdict": "<detailed paragraph: final safety verdict>"
}`;

const DEEP_IMAGE_PROMPT = `You are a forensic image authenticity analyst. Determine if this image is AI-generated.
Be specific — cite exact regions, objects, and artifacts. Be honest about uncertainty.

CRITICAL FACTUALITY RULE:
Step 1: Look at the image. Is there a visible paragraph, article headline, news caption, or any significant block of readable written text IN the image itself?
Step 2a: If YES — fill factualityScore (0-100) and factualClaims with the readable text you see.
Step 2b: If NO — you MUST output: "factualityScore": null  and  "factualClaims": []
Do NOT fill factualityScore with a number just because the image is authentic. Only fill it when there is readable text to fact-check.

Return ONLY raw JSON (no markdown, no code fences):
{
  "aiProbability": <integer 0-100>,
  "confidence": "<'high' | 'medium' | 'low'>",
  "verdict": "<one clear sentence verdict>",
  "factualityScore": null,
  "factualClaims": [],
  "anatomicalAnalysis": "<detailed paragraph: hands, faces, eyes, hair — exact observations>",
  "lightingAnalysis": "<detailed paragraph: light source consistency, shadow directions, reflections>",
  "textureAnalysis": "<detailed paragraph: skin, fabric, background texture — AI smoothing or artifacts>",
  "crossChecks": [
    {"signal": "<specific visual element>", "interpretation": "<what this tells us>", "weight": "<'strong' | 'moderate' | 'weak'>"}
  ],
  "overallVerdict": "<detailed paragraph: final authenticity verdict>"
}

REMINDER: Only replace the null and [] above with real values if you can read actual text paragraphs or headlines IN the image.`;

// PASS 2 — Summary for the extension card only (NOT saved to DB)
const SUMMARY_PROMPT = `You are given a detailed forensic analysis report.
Write a SHORT, CLEAR summary for a non-expert user to read in a browser extension overlay card.

Rules:
- Maximum 2 sentences for the reason
- Maximum 4 signal chips (2-4 words each)
- Include factualityScore as a percentage in shortVerdict if relevant
- Be direct and honest. No jargon.

Return ONLY raw JSON (no markdown, no code fences):
{
  "shortVerdict": "<1-sentence verdict, e.g. 'Likely AI-generated · 34% factual'>",
  "reason": "<2 sentences: most important evidence in plain language>",
  "chips": ["<2-4 word signal>", "<2-4 word signal>", "<2-4 word signal>", "<2-4 word signal>"],
  "factualityScore": <integer 0-100, copy from the deep analysis>
}`;

// ── Background entry ───────────────────────────────────────────────────────
export default defineBackground(() => {

  // On install/startup — check pool and refill if needed
  browser.runtime.onInstalled.addListener(() => {
    setupContextMenus();
    console.log('[VeriMata] Extension installed — checking quiz pool...');
    checkAndRefillPool().catch(e => console.error('[VeriMata] Pool refill error:', e));
  });

  browser.runtime.onStartup.addListener(() => {
    console.log('[VeriMata] Extension started — checking quiz pool...');
    checkAndRefillPool().catch(e => console.error('[VeriMata] Pool refill error:', e));
  });

  browser.contextMenus.onClicked.addListener(async (info, tab) => {
    if (!tab?.id) return;
    try {
      // Inject content script — WXT's executeScript is idempotent when the
      // script checks a guard flag, but we still need to inject to register
      // the listener on first use. The content script itself guards against
      // double-initialisation via a window flag.
      await browser.scripting.executeScript({
        target: { tabId: tab.id },
        files: ['/content-scripts/content.js'],
      });
    } catch (err) {
      // Script may already be injected — that's fine, continue
      console.warn('[VeriMata] Content script inject (may already exist):', err);
    }

    if (info.menuItemId === 'spot-the-bot-analyze-image' && info.srcUrl) {
      browser.tabs.sendMessage(tab.id, { type: 'ANALYZE_IMAGE', imageUrl: info.srcUrl, pageUrl: info.pageUrl });
      return;
    }
    if (info.menuItemId === 'spot-the-bot-analyze-video' && info.srcUrl) {
      browser.tabs.sendMessage(tab.id, { type: 'ANALYZE_VIDEO', videoUrl: info.srcUrl, pageUrl: info.pageUrl });
      return;
    }
    if (info.menuItemId === 'spot-the-bot-analyze') {
      browser.tabs.sendMessage(tab.id, { type: 'ANALYZE_SELECTION', text: info.selectionText, pageUrl: info.pageUrl });
    }
  });

  browser.runtime.onMessage.addListener((rawMessage, _sender, sendResponse) => {
    const message = rawMessage as Record<string, any>;
    console.log('[VeriMata] Message:', message.type);

    if (message.type === 'REQUEST_ANALYSIS') {
      analyzeContent(message.text, message.pageUrl, message.imageUrl)
        .then(result => sendResponse({ ok: true, result }))
        .catch(err => sendResponse({ ok: false, error: String(err) }));
      return true;
    }

    if (message.type === 'SYNC_WEBSITE_SESSION') {
      syncWebsiteSession()
        .then(result => sendResponse(result))
        .catch(() => sendResponse({ ok: false, reason: 'error' }));
      return true;
    }

    if (message.type === 'GET_FLAG_COUNT') {
      getFlagCount(message.postUrl as string)
        .then(count => sendResponse({ ok: true, count }))
        .catch(err => sendResponse({ ok: false, count: 0, error: String(err) }));
      return true;
    }

    if (message.type === 'OPEN_DASHBOARD') {
      browser.tabs.create({ url: browser.runtime.getURL('/dashboard.html') });
    }

    if (message.type === 'OPEN_WEB_APP') {
      const targetUrl = message.url as string;
      // Check if a tab with the web app is already open — focus and reload it instead of opening a new tab
      browser.tabs.query({ url: 'https://veri-mata.vercel.app/*' }).then(tabs => {
        if (tabs.length > 0 && tabs[0].id) {
          browser.tabs.update(tabs[0].id, { active: true, url: targetUrl });
          if (tabs[0].windowId) browser.windows.update(tabs[0].windowId, { focused: true });
        } else {
          browser.tabs.create({ url: targetUrl });
        }
      });
    }

    if (message.type === 'REFILL_POOL') {
      checkAndRefillPool()
        .then(() => sendResponse({ ok: true }))
        .catch(err => sendResponse({ ok: false, error: String(err) }));
      return true;
    }

    return true;
  });
});

function setupContextMenus() {
  browser.contextMenus.create({ id: 'spot-the-bot-analyze', title: 'Analyze with VeriMata', contexts: ['selection', 'page'] });
  browser.contextMenus.create({ id: 'spot-the-bot-analyze-image', title: 'Analyze image with VeriMata', contexts: ['image'] });
  browser.contextMenus.create({ id: 'spot-the-bot-analyze-video', title: 'Analyze video with VeriMata', contexts: ['video'] });
}

// ── Quiz Pool ──────────────────────────────────────────────────────────────

async function checkAndRefillPool() {
  const [textCount, imageCount] = await Promise.all([
    getPoolCount('quiz_pool_text'),
    getPoolCount('quiz_pool_image'),
  ]);
  console.log(`[VeriMata] Pool: text=${textCount}/${TEXT_POOL_TARGET}, image=${imageCount}/${IMAGE_POOL_TARGET}`);

  const textNeeded = Math.max(0, TEXT_POOL_TARGET - textCount);
  const imageNeeded = Math.max(0, IMAGE_POOL_TARGET - imageCount);

  if (textNeeded === 0 && imageNeeded === 0) {
    console.log('[VeriMata] Pool full, no refill needed');
    return;
  }

  // Text is fast — do it first
  if (textNeeded > 0) {
    console.log(`[VeriMata] Refilling ${textNeeded} text questions...`);
    await refillTextPool(textNeeded);
  }

  // Images are slow — run after text
  if (imageNeeded > 0) {
    console.log(`[VeriMata] Refilling ${imageNeeded} image questions...`);
    await refillImagePool(imageNeeded);
  }

  console.log('[VeriMata] Pool refill complete');
}

async function getPoolCount(table: string): Promise<number> {
  const key = SUPABASE_SERVICE;
  const res = await fetch(`${SUPABASE_URL}/rest/v1/${table}?select=id`, {
    method: 'GET',
    headers: {
      Authorization: `Bearer ${key}`,
      apikey: key,
      Prefer: 'count=exact',
      'Range-Unit': 'items',
      Range: '0-0',
    },
  });
  if (!res.ok) {
    console.warn(`[VeriMata] getPoolCount ${table} failed: ${res.status}`);
    return 0;
  }
  // Supabase returns count in Content-Range header: "0-0/COUNT"
  const contentRange = res.headers.get('content-range') ?? '';
  const match = contentRange.match(/\/(\d+)/);
  if (match) return parseInt(match[1], 10);
  // Fallback: parse response array length
  const text = await res.text().catch(() => '[]');
  try { return JSON.parse(text).length; } catch { return 0; }
}

async function refillTextPool(needed: number) {
  const shuffled = [...TOPICS].sort(() => Math.random() - 0.5);
  let inserted = 0;

  while (inserted < needed) {
    const batch = Math.min(3, needed - inserted);
    const batchTopics = shuffled.splice(0, batch);

    try {
      const raw = await callGemini(`Generate ${batch} quiz questions for a "Spot the AI" game.
Each shows two texts — one human-written, one AI-generated — player identifies the AI one.

Return ONLY a valid JSON array, no markdown:
[
  {
    "topic": "brief topic",
    "human_content": "naturally written human text, 2-4 sentences, personal and specific",
    "ai_content": "AI-generated version, formal and generic sounding",
    "explanation": "2-3 sentences explaining specific AI tells in the ai_content"
  }
]

Topics: ${batchTopics.join(', ')}`);

      const match = raw.match(/\[[\s\S]*\]/);
      if (!match) { console.warn('[VeriMata] No JSON array in text generation response'); continue; }

      const questions = JSON.parse(match[0]);
      const valid = questions.filter((q: any) =>
        q.topic?.trim() &&
        q.human_content?.trim().length > 20 &&
        q.ai_content?.trim().length > 20 &&
        q.explanation?.trim().length > 20
      ).slice(0, needed - inserted);

      if (valid.length === 0) continue;

      const rows = valid.map((q: any) => ({
        topic: q.topic.trim(),
        human_content: q.human_content.trim(),
        ai_content: q.ai_content.trim(),
        explanation: q.explanation.trim(),
      }));

      await supabaseRest('quiz_pool_text', 'POST', rows, true);
      inserted += rows.length;
      console.log(`[VeriMata] Text pool: inserted ${rows.length}, total ${inserted}/${needed}`);
    } catch (e) {
      console.error('[VeriMata] Text generation error:', e);
    }
  }
}

async function refillImagePool(needed: number) {
  const shuffled = [...TOPICS].sort(() => Math.random() - 0.5);
  let inserted = 0;

  for (let i = 0; i < needed; i++) {
    const topic = shuffled[i % shuffled.length];

    if (i > 0) {
      console.log(`[VeriMata] Waiting 15s before next image...`);
      await new Promise(r => setTimeout(r, 15000));
    }

    console.log(`[VeriMata] Image ${i + 1}/${needed}: "${topic}"`);

    const realImageUrl = await searchRealImage(`${topic} photograph`);
    if (!realImageUrl) { console.warn(`[VeriMata] No real image for "${topic}"`); continue; }

    const aiImageData = await generateAiImage(`Photorealistic photo of ${topic}. Natural lighting, candid style.`);
    if (!aiImageData) { console.warn(`[VeriMata] AI image failed for "${topic}"`); continue; }

    let explanation = `AI-generated images of "${topic}" often show unnatural textures, overly perfect lighting, and fine detail distortions.`;
    try {
      const exp = await callGemini(`An AI image was generated of "${topic}". Write 2-3 sentences about specific visual tells: texture issues, lighting anomalies, fine detail errors. Be concise.`);
      if (exp.trim().length > 20) explanation = exp.trim();
    } catch { /* use default */ }

    await supabaseRest('quiz_pool_image', 'POST', [{
      topic,
      real_image_url: realImageUrl,
      ai_image_data: aiImageData,
      explanation,
    }], true);

    inserted++;
    console.log(`[VeriMata] Image pool: inserted ${inserted}/${needed} — "${topic}"`);
  }
}

// ── Content Analysis ───────────────────────────────────────────────────────
// Extension calls Gemini directly (no timeout issues) using a key fetched
// securely from Vercel on first use — key is never in the bundle.

async function analyzeContent(text?: string, pageUrl?: string, imageUrl?: string) {
  console.log('[VeriMata] Analyzing content...');

  let deep: any;
  let contentType: string;
  let subject: string;

  if (imageUrl) {
    deep = await deepAnalyzeImage(imageUrl);
    contentType = 'image';
    subject = imageUrl;
  } else if (text) {
    const isLink = /^https?:\/\/\S+$/i.test(text.trim());
    if (isLink) {
      deep = await deepAnalyzeLink(text.trim());
      contentType = 'link';
      subject = text.trim();
    } else {
      deep = await deepAnalyzeText(text.trim());
      contentType = 'text';
      subject = text.trim().slice(0, 200);
    }
  } else {
    throw new Error('No content to analyze');
  }

  const summary = await generateSummary(deep);

  void saveAnalysisToDb(deep, summary, contentType, subject);

  return {
    aiProbability: deep.aiProbability ?? 50,
    shortVerdict: summary.shortVerdict ?? deep.verdict ?? 'Analysis complete.',
    reason: summary.reason ?? '',
    chips: summary.chips ?? [],
    confidence: deep.confidence ?? 'medium',
    factualityScore: deep.factualityScore ?? null,
    biasFlags: summary.chips ?? [],
    reasoning: summary.reason ?? '',
    factCheckRefs: [],
  };
}

async function saveAnalysisToDb(deep: any, summary: any, contentType: string, subject: string) {
  const stored = await chrome.storage.local.get(['sb_session', 'sb_full_session']);
  const accessToken = stored?.sb_full_session?.access_token ?? stored?.sb_session?.access_token;

  if (!accessToken) {
    return;
  }

  try {
    const saveRes = await fetch(`${SUPABASE_URL}/rest/v1/analysis_results`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${accessToken}`,
        apikey: SUPABASE_ANON,
        Prefer: 'return=minimal',
      },
      body: JSON.stringify({
        content_type: contentType,
        subject,
        ai_probability: deep.aiProbability ?? 50,
        verdict: deep.verdict ?? '',
        summary_flags: summary.chips ?? [],
        summary_reason: summary.reason ?? '',
        deep_analysis: deep,
        cross_checks: deep.crossChecks ?? [],
        confidence: deep.confidence ?? 'medium',
        factuality_score: deep.factualityScore ?? null,
        factual_claims: deep.factualClaims ?? [],
        analyzed_at: new Date().toISOString(),
      }),
    });

    if (!saveRes.ok) {
      const err = await saveRes.text();
      console.warn('[VeriMata] analysis_results save failed:', saveRes.status, err);
    } else {
      console.log('[VeriMata] Analysis result saved to DB');
    }
  } catch (e) {
    console.warn('[VeriMata] Could not save analysis result:', e);
  }
}

async function deepAnalyzeText(text: string) {
  const raw = await callGemini(`${DEEP_TEXT_PROMPT}\n\nText to analyze:\n"""\n${text}\n"""`);
  return safeParseJson(raw);
}

async function deepAnalyzeLink(url: string) {
  const raw = await callGemini(`${DEEP_LINK_PROMPT}\n\nURL to analyze:\n${url}`);
  return safeParseJson(raw);
}

async function deepAnalyzeImage(imageUrl: string) {
  try {
    const res = await fetch(imageUrl, {
      headers: { 'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36' },
      signal: AbortSignal.timeout(10000),
    });
    if (!res.ok) throw new Error(`Image fetch failed: ${res.status}`);
    const buffer = await res.arrayBuffer();
    const ct = res.headers.get('content-type') || 'image/jpeg';
    const base64 = btoa(String.fromCharCode(...new Uint8Array(buffer)));
    const raw = await callGeminiWithImage(`${DEEP_IMAGE_PROMPT}\n\nAnalyze this image:`, base64, ct.split(';')[0].trim());
    const parsed = safeParseJson(raw);
    // Guard: if no factual claims were found, force factualityScore to null
    if (!parsed.factualClaims || parsed.factualClaims.length === 0) {
      parsed.factualityScore = null;
      parsed.factualClaims = [];
    }
    return parsed;
  } catch {
    const raw = await callGemini(`${DEEP_IMAGE_PROMPT}\n\nAnalyze this image URL (no image data available): ${imageUrl}`);
    const parsed = safeParseJson(raw);
    if (!parsed.factualClaims || parsed.factualClaims.length === 0) {
      parsed.factualityScore = null;
      parsed.factualClaims = [];
    }
    return parsed;
  }
}

async function generateSummary(deepResult: any) {
  const condensed = JSON.stringify({
    aiProbability: deepResult.aiProbability,
    confidence: deepResult.confidence,
    verdict: deepResult.verdict,
    overallVerdict: deepResult.overallVerdict,
    crossChecks: deepResult.crossChecks?.slice(0, 3),
  });
  const raw = await callGemini(`${SUMMARY_PROMPT}\n\nDeep analysis report:\n${condensed}`);
  return safeParseJson(raw);
}

// ── Gemini REST helpers ────────────────────────────────────────────────────

async function callGemini(prompt: string): Promise<string> {
  const key = await getGeminiKey();
  const url = `https://generativelanguage.googleapis.com/v1beta/models/${GEMINI_MODEL}:generateContent?key=${key}`;
  const res = await fetch(url, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ contents: [{ parts: [{ text: prompt }] }] }),
  });
  if (!res.ok) {
    // If 401, clear cached key so next call re-fetches
    if (res.status === 401 || res.status === 403) {
      _geminiKeyMemory = null;
      try { await chrome.storage.session.remove('gemini_key'); } catch { /* non-fatal */ }
    }
    throw new Error(`Gemini error: ${res.status} ${await res.text()}`);
  }
  const data = await res.json();
  return data.candidates?.[0]?.content?.parts?.[0]?.text ?? '';
}

async function callGeminiWithImage(prompt: string, base64: string, mimeType: string): Promise<string> {
  const key = await getGeminiKey();
  const url = `https://generativelanguage.googleapis.com/v1beta/models/${GEMINI_MODEL}:generateContent?key=${key}`;
  const res = await fetch(url, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      contents: [{
        parts: [
          { text: prompt },
          { inlineData: { mimeType, data: base64 } },
        ],
      }],
    }),
  });
  if (!res.ok) {
    if (res.status === 401 || res.status === 403) {
      _geminiKeyMemory = null;
      try { await chrome.storage.session.remove('gemini_key'); } catch { /* non-fatal */ }
    }
    throw new Error(`Gemini error: ${res.status} ${await res.text()}`);
  }
  const data = await res.json();
  return data.candidates?.[0]?.content?.parts?.[0]?.text ?? '';
}

// ── Image helpers ──────────────────────────────────────────────────────────

async function searchRealImage(query: string): Promise<string | null> {
  if (!SERP_KEY) return null;
  try {
    const url = `https://serpapi.com/search.json?engine=google_images&q=${encodeURIComponent(query)}&api_key=${SERP_KEY}&num=10&safe=active`;
    const res = await fetch(url);
    if (!res.ok) return null;
    const data = await res.json();
    const images = (data.images_results as { original: string }[] | undefined) || [];
    for (const img of images.filter(i => i.original?.startsWith('http'))) {
      if (await validateImageUrl(img.original)) return img.original;
    }
    return null;
  } catch { return null; }
}

async function validateImageUrl(url: string): Promise<boolean> {
  try {
    const head = await fetch(url, { method: 'HEAD', signal: AbortSignal.timeout(5000) });
    return head.ok && (head.headers.get('content-type') || '').startsWith('image/');
  } catch { return false; }
}

async function generateAiImage(prompt: string): Promise<string | null> {
  for (let attempt = 1; attempt <= 4; attempt++) {
    if (attempt > 1) await new Promise(r => setTimeout(r, attempt * 15000));
    try {
      const url = `https://image.pollinations.ai/prompt/${encodeURIComponent(prompt)}?width=512&height=512&nologo=true&seed=${Math.floor(Math.random() * 999999)}&model=flux`;
      const controller = new AbortController();
      const timeout = setTimeout(() => controller.abort(), 120000);
      const res = await fetch(url, { signal: controller.signal });
      clearTimeout(timeout);
      if (!res.ok || res.status === 429) continue;
      const ct = res.headers.get('content-type') || '';
      if (!ct.startsWith('image/')) continue;
      const buffer = await res.arrayBuffer();
      if (buffer.byteLength < 1000) continue;
      const base64 = btoa(String.fromCharCode(...new Uint8Array(buffer)));
      return `data:${ct};base64,${base64}`;
    } catch { continue; }
  }
  return null;
}

// ── Supabase REST helpers ──────────────────────────────────────────────────

async function supabaseRest(
  table: string,
  method: string,
  body: any,
  useServiceKey: boolean,
  prefer = 'return=minimal'
) {
  const key = useServiceKey ? SUPABASE_SERVICE : SUPABASE_ANON;
  const res = await fetch(`${SUPABASE_URL}/rest/v1/${table}`, {
    method,
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${key}`,
      apikey: key,
      Prefer: prefer,
    },
    body: body ? JSON.stringify(body) : undefined,
  });
  if (!res.ok) {
    const err = await res.text().catch(() => '');
    throw new Error(`Supabase ${method} ${table} failed (${res.status}): ${err}`);
  }
  const text = await res.text();
  return text ? JSON.parse(text) : null;
}

async function supabaseFetch(path: string, method: string, body: any, useServiceKey: boolean) {
  const key = useServiceKey ? SUPABASE_SERVICE : SUPABASE_ANON;
  const res = await fetch(`${SUPABASE_URL}${path}`, {
    method,
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${key}`,
      apikey: key,
    },
    body: body ? JSON.stringify(body) : undefined,
  });
  if (!res.ok) throw new Error(`Supabase fetch ${path} failed (${res.status})`);
  return res.json();
}

// ── Website session sync (Option A) ───────────────────────────────────────

// Finds an open tab on veri-mata.vercel.app, asks the website-session content
// script to read Supabase's localStorage, then stores the tokens so the
// popup and background can use them without the user signing in separately.
async function syncWebsiteSession(): Promise<{ ok: boolean; reason?: string }> {
  const tabs = await browser.tabs.query({ url: 'https://veri-mata.vercel.app/*' });
  if (tabs.length === 0) return { ok: false, reason: 'no_tab' };

  const tab = tabs.find(t => t.id != null);
  if (!tab?.id) return { ok: false, reason: 'no_tab' };

  let response: any;
  try {
    response = await browser.tabs.sendMessage(tab.id, { type: 'GET_WEBSITE_SESSION' });
  } catch {
    // Content script not injected yet — inject it now and retry once
    try {
      await browser.scripting.executeScript({
        target: { tabId: tab.id },
        files: ['/content-scripts/website-session.js'],
      });
      response = await browser.tabs.sendMessage(tab.id, { type: 'GET_WEBSITE_SESSION' });
    } catch {
      return { ok: false, reason: 'inject_failed' };
    }
  }

  if (!response?.ok || !response.session) return { ok: false, reason: 'no_session' };

  const { access_token, refresh_token } = response.session;

  // Store for popup and background use
  await chrome.storage.local.set({
    sb_full_session: { access_token, refresh_token },
    sb_session: { access_token },
  });

  return { ok: true };
}

// ── Flag count ─────────────────────────────────────────────────────────────

// Count how many flag_reports rows exist for a given URL
async function getFlagCount(postUrl: string): Promise<number> {
  const url = `${SUPABASE_URL}/rest/v1/flag_reports?post_url=eq.${encodeURIComponent(postUrl)}&select=id`;
  const res = await fetch(url, {
    headers: {
      Authorization: `Bearer ${SUPABASE_ANON}`,
      apikey: SUPABASE_ANON,
      Prefer: 'count=exact',
    },
  });
  if (!res.ok) return 0;
  // Supabase returns count in Content-Range header when Prefer: count=exact
  const range = res.headers.get('content-range'); // e.g. "0-4/5"
  if (range) {
    const total = range.split('/')[1];
    if (total && total !== '*') return parseInt(total, 10);
  }
  // Fallback: count the returned rows
  const rows = await res.json().catch(() => []);
  return Array.isArray(rows) ? rows.length : 0;
}

// ── Helpers ────────────────────────────────────────────────────────────────

function safeParseJson(raw: string): any {
  const stripped = raw.replace(/^```(?:json)?\s*/i, '').replace(/\s*```$/m, '').trim();
  try { return JSON.parse(stripped); } catch { /* fall through */ }
  const match = stripped.match(/\{[\s\S]*\}/);
  if (match) { try { return JSON.parse(match[0]); } catch { /* fall through */ } }
  return {};
}
