import { createClient } from '@supabase/supabase-js';

// Same project as the analyze-content Edge Function in background.ts.
// The anon key is safe to ship in the extension bundle — it's the public
// key, and Row Level Security policies (see supabase/migrations) are what
// actually control what it's allowed to do (insert flags, read flags).
export const SUPABASE_URL = import.meta.env.VITE_SUPABASE_URL as string;
export const SUPABASE_ANON_KEY = import.meta.env.VITE_SUPABASE_ANON_KEY as string;

export const supabase = createClient(SUPABASE_URL, SUPABASE_ANON_KEY);

// One row per unique URL/content — the registry entry.
export interface FlaggedPost {
  id: string;
  created_at: string;
  post_url: string;
  snippet: string | null;
  ai_probability: number;
  bias_flags: string[];
  reasoning: string | null;
  flag_count: number;
}

// One row per user flag action — attached to a FlaggedPost.
export interface FlagReport {
  id: string;
  created_at: string;
  flag_id: string;
  user_id: string | null;
  user_email: string | null;
  reason: string;
  category: string | null;
}

// Sent from the extension popup/content to the background to register a URL.
export interface FlagSubmission {
  postUrl: string;
  snippet?: string;
  aiProbability: number;
  biasFlags: string[];
  reasoning: string;
}
