import React from 'react';
import ReactDOM from 'react-dom/client';
import Popup from './Popup';

const root = document.getElementById('root') ?? document.createElement('div');
if (!root.isConnected) document.body.appendChild(root);
ReactDOM.createRoot(root).render(<Popup />);
