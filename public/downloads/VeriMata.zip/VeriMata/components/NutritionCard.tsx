import React, { useRef, useState } from 'react';
import logoUrl from '../images/logo.png';

// SVG icons — no emojis
const IconShield = ({ size = 14 }: { size?: number }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
    <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/>
  </svg>
);
const IconAlert = ({ size = 14 }: { size?: number }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
    <path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/>
  </svg>
);
const IconCheck = ({ size = 14 }: { size?: number }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round">
    <polyline points="20 6 9 17 4 12"/>
  </svg>
);
const IconSearch = ({ size = 12 }: { size?: number }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
    <circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/>
  </svg>
);
const IconLink = ({ size = 12 }: { size?: number }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
    <path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"/><polyline points="15 3 21 3 21 9"/><line x1="10" y1="14" x2="21" y2="3"/>
  </svg>
);
const IconFlag = ({ size = 13 }: { size?: number }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
    <path d="M4 15s1-1 4-1 5 2 8 2 4-1 4-1V3s-1 1-4 1-5-2-8-2-4 1-4 1z"/><line x1="4" y1="22" x2="4" y2="15"/>
  </svg>
);

export interface AnalysisResult {
  aiProbability: number;
  shortVerdict?: string;
  reason?: string;
  chips?: string[];
  confidence?: 'high' | 'medium' | 'low';
  factualityScore?: number | null;
  // Legacy compat
  biasFlags?: string[];
  reasoning?: string;
  factCheckRefs?: { label: string; url: string }[];
}

type CardState =
  | { status: 'loading' }
  | { status: 'done'; data: AnalysisResult }
  | { status: 'error'; message: string };

interface LinkGateProps {
  riskThreshold: number;
  onProceed: () => void;
  onCancel: () => void;
}

type FlagStatus = 'idle' | 'opening' | 'flagged' | 'error';

interface Props {
  state: CardState;
  onClose: () => void;
  onFeedback?: (verdict: 'agree' | 'dispute') => void;
  onFlag?: () => void;
  flagStatus?: FlagStatus;
  flagCount?: number;
  flagError?: string | null;
  linkGate?: LinkGateProps;
  analyzedUrl?: string;
  contentType?: 'text' | 'link' | 'image';
}

const WEB_APP_URL = 'https://veri-mata.vercel.app';

// Rex "Case File" palette — matches the website
const C = {
  bg: '#ffffff',
  foreground: '#191c3a',
  muted: '#666b93',
  border: '#dfe1f4',
  primary: '#5b46f0',
  primaryDark: '#4835d4',
  secondary: '#0aa66e',
  accent: '#ffb422',
  destructive: '#e6473d',
  ink: '#191c3a',
};

export default function NutritionCard({
  state,
  onClose,
  onFeedback,
  onFlag,
  flagStatus = 'idle',
  flagCount = 0,
  flagError,
  linkGate,
  analyzedUrl,
  contentType,
}: Props) {
  const isRisky = state.status === 'done' && !!linkGate && state.data.aiProbability >= linkGate.riskThreshold;
  const cardRef = useRef<HTMLDivElement>(null);  const [pos, setPos] = useState<{ top: number; left: number } | null>(null);
  const drag = useRef<{ startX: number; startY: number; startTop: number; startLeft: number } | null>(null);
  const onMouseMoveRef = useRef<(e: MouseEvent) => void>(() => {});
  const onMouseUpRef = useRef<() => void>(() => {});

  onMouseMoveRef.current = (e: MouseEvent) => {
    if (!drag.current) return;
    const rect = cardRef.current?.getBoundingClientRect();
    const width = rect?.width ?? 340;
    setPos({
      top: Math.min(Math.max(drag.current.startTop + (e.clientY - drag.current.startY), 0), window.innerHeight - 32),
      left: Math.min(Math.max(drag.current.startLeft + (e.clientX - drag.current.startX), -width + 40), window.innerWidth - 40),
    });
  };
  onMouseUpRef.current = () => {
    drag.current = null;
    document.removeEventListener('mousemove', stableMouseMove);
  };
  const stableMouseMove = useRef((e: MouseEvent) => onMouseMoveRef.current(e)).current;
  const stableMouseUp = useRef(() => onMouseUpRef.current()).current;

  function onHeaderMouseDown(e: React.MouseEvent) {
    if ((e.target as HTMLElement).closest('button')) return;
    const rect = cardRef.current?.getBoundingClientRect();
    if (!rect) return;
    drag.current = { startX: e.clientX, startY: e.clientY, startTop: rect.top, startLeft: rect.left };
    document.addEventListener('mousemove', stableMouseMove);
    document.addEventListener('mouseup', stableMouseUp, { once: true });
    e.preventDefault();
  }

  function openMoreDetails() {
    if (state.status !== 'done') return;
    browser.runtime.sendMessage({
      type: 'OPEN_WEB_APP',
      url: `${WEB_APP_URL}/dashboard/analyzer?from=extension`,
    });
  }

  const positionStyle: React.CSSProperties = pos ? { top: pos.top, left: pos.left, right: 'auto' } : {};

  // Derive score color
  const score = state.status === 'done' ? state.data.aiProbability : 0;
  const scoreColor = score >= 70 ? C.destructive : score >= 40 ? C.accent : C.secondary;
  const scoreLabel = score >= 70 ? 'High Risk' : score >= 40 ? 'Uncertain' : 'Low Risk';
  const fscore = state.status === 'done' ? (state.data.factualityScore ?? null) : null;
  const fColor = fscore == null ? C.secondary : fscore >= 60 ? C.secondary : fscore >= 35 ? C.accent : C.destructive;

  return (
    <div ref={cardRef} style={{ ...styles.card, ...positionStyle }}>
      <style>{`
        @keyframes vm-spin {
          to { transform: rotate(360deg); }
        }
        .vm-spinner {
          animation: vm-spin 0.75s linear infinite;
        }
      `}</style>
      {/* Header */}
      <div
        style={{ ...styles.header, ...(isRisky ? { background: '#7f1d1d' } : {}) }}
        onMouseDown={onHeaderMouseDown}
        title="Drag to move"
      >
        <span style={styles.dragHandle}>⠿</span>
        <span style={{ ...styles.headerTitle, display: 'flex', alignItems: 'center', gap: 6 }}>
          <img src={logoUrl} alt="VeriMata" style={{ width: 18, height: 18, borderRadius: 4, objectFit: 'contain', flexShrink: 0 }} />
          {linkGate
            ? (isRisky ? 'Risky Link' : 'Link Check')
            : 'VeriMata'}
        </span>
        {!linkGate && (
          <button style={styles.closeBtn} onClick={onClose} aria-label="Close">×</button>
        )}
      </div>

      {/* URL bar */}
      {analyzedUrl && (
        <div style={styles.urlBar}>
          <span style={styles.urlBarLabel}>Checking</span>
          <span style={styles.urlBarValue} title={analyzedUrl}>{truncateUrl(analyzedUrl, 38)}</span>
        </div>
      )}

      {/* Loading */}
      {state.status === 'loading' && (
        <div style={styles.body}>
          <div style={styles.loadingRow}>
            <div style={styles.spinner} className="vm-spinner" />
            <span style={styles.loadingText}>
              {linkGate ? 'Checking link safety…' : 'Analyzing content…'}
            </span>
          </div>
        </div>
      )}

      {/* Error */}
      {state.status === 'error' && (
        <div style={styles.body}>
          <div style={styles.errorBox}>
            <span style={styles.errorIcon}>⚠</span>
            <p style={styles.errorText}>{state.message}</p>
          </div>
          {linkGate && (
            <div style={styles.actionRow}>
              <button style={styles.actionBtn} onClick={linkGate.onCancel}>Cancel</button>
              <button style={{ ...styles.actionBtn, ...styles.cautionBtn }} onClick={linkGate.onProceed}>Proceed anyway</button>
            </div>
          )}
        </div>
      )}

      {/* Result */}
      {state.status === 'done' && (
        <div style={styles.body}>
          {/* Score gauge */}
          <div style={styles.gaugeSection}>
            <div style={styles.gaugeHeader}>
              <span style={styles.gaugeLabel}>{linkGate ? 'Risk Score' : 'AI Likelihood'}</span>
              <div style={styles.gaugeRight}>
                <span style={{ ...styles.gaugeScore, color: scoreColor }}>{score}%</span>
                <span style={{ ...styles.gaugeBadge, background: scoreColor + '22', color: scoreColor, border: `1px solid ${scoreColor}44` }}>
                  {scoreLabel}
                </span>
              </div>
            </div>
            <div style={styles.gaugeTrack}>
              <div style={{ ...styles.gaugeFill, width: `${score}%`, background: scoreColor }} />
            </div>
            {state.data.confidence && (
              <p style={styles.confidenceText}>
                Confidence: <strong>{state.data.confidence}</strong>
              </p>
            )}
          </div>

        {/* Factuality score — only shown when present */}
          {fscore != null && (
            <div style={{ ...styles.gaugeSection, marginTop: -4 }}>
              <div style={styles.gaugeHeader}>
                <span style={styles.gaugeLabel}>Factuality</span>
                <span style={{
                  fontSize: 16, fontWeight: 800, lineHeight: 1, fontFamily: 'monospace',
                  color: fColor,
                }}>
                  {fscore}%
                </span>
              </div>
              <div style={styles.gaugeTrack}>
                <div style={{ ...styles.gaugeFill, width: `${fscore}%`, background: fColor }} />
              </div>
              <p style={styles.confidenceText}>
                {fscore >= 60
                  ? 'Claims appear mostly supported'
                  : fscore >= 35
                  ? 'Some claims are unverifiable'
                  : 'Claims appear unsupported or fabricated'}
              </p>
            </div>
          )}

          {/* Verdict */}
          {(state.data.shortVerdict || state.data.biasFlags?.length) && (
            <div style={{ ...styles.verdictBox, borderColor: scoreColor + '44', background: scoreColor + '0d' }}>
              <span style={{ ...styles.verdictIcon, color: scoreColor }}>
                {score >= 70 ? <IconAlert /> : <IconCheck />}
              </span>
              <p style={{ ...styles.verdictText, color: scoreColor === C.secondary ? '#065f46' : scoreColor === C.accent ? '#78350f' : '#7f1d1d' }}>
                {state.data.shortVerdict ?? (score >= 70 ? 'Likely AI-generated' : score >= 40 ? 'Uncertain — could be AI' : 'Likely human / safe')}
              </p>
            </div>
          )}

          {/* Signal chips */}
          {(() => {
            const chips = state.data.chips?.length ? state.data.chips : state.data.biasFlags;
            return chips && chips.length > 0 ? (
              <div style={styles.chipsSection}>
                <p style={styles.sectionLabel}>DETECTED SIGNALS</p>
                <div style={styles.chipsRow}>
                  {chips.map((chip, i) => (
                    <span key={i} style={styles.chip}>{chip}</span>
                  ))}
                </div>
              </div>
            ) : null;
          })()}

          {/* Reason */}
          {(state.data.reason || state.data.reasoning) && (
            <div style={styles.reasonSection}>
              <p style={styles.sectionLabel}>SUMMARY</p>
              <p style={styles.reasonText}>{state.data.reason ?? state.data.reasoning}</p>
            </div>
          )}

          {/* More Details button */}
          <button style={styles.moreDetailsBtn} onClick={openMoreDetails}>
            <span style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
              <IconSearch size={12} />
              Full Deep Analysis
            </span>
            <IconLink size={12} />
          </button>

          {/* Action row */}
          {linkGate ? (
            <div style={styles.actionRow}>
              <button style={styles.actionBtn} onClick={linkGate.onCancel}>Cancel</button>
              <button style={{ ...styles.actionBtn, ...(isRisky ? styles.cautionBtn : styles.safeBtn) }} onClick={linkGate.onProceed}>
                {isRisky ? 'Proceed anyway' : 'Continue to link'}
              </button>
            </div>
          ) : onFlag ? (
            <div style={styles.flagRow}>
              <button
                style={{
                  ...styles.flagBtn,
                  ...(flagStatus === 'flagged' || flagStatus === 'opening' ? styles.flagBtnDone : {}),
                }}
                onClick={onFlag}
                disabled={flagStatus === 'opening' || flagStatus === 'flagged'}
              >
                <span style={{ display: 'flex', alignItems: 'center', gap: 5 }}>
                  <IconFlag size={13} />
                  {flagStatus === 'opening'
                    ? 'Opening…'
                    : flagStatus === 'flagged'
                    ? 'Opened ✓'
                    : flagStatus === 'error'
                    ? 'Retry'
                    : 'Flag this'}
                </span>
                {flagCount > 0 && flagStatus === 'idle' && (
                  <span style={styles.flagCountBadge}>
                    {flagCount} {flagCount === 1 ? 'person' : 'people'} flagged
                  </span>
                )}
              </button>
            </div>
          ) : null}

          {flagStatus === 'flagged' && (
            <p style={styles.flagNote}>Submit your reason on the flags page.</p>
          )}
          {flagStatus === 'error' && (
            <p style={styles.flagNoteError}>Something went wrong{flagError ? `: ${flagError}` : '.'}</p>
          )}
        </div>
      )}
    </div>
  );
}

function truncateUrl(url: string, max: number): string {
  try {
    const { hostname, pathname } = new URL(url);
    const full = hostname + pathname.replace(/\/$/, '');
    return full.length > max ? full.slice(0, max) + '…' : full;
  } catch {
    return url.length > max ? url.slice(0, max) + '…' : url;
  }
}

const styles: Record<string, React.CSSProperties> = {
  card: {
    width: 340,
    fontFamily: 'system-ui, -apple-system, sans-serif',
    fontSize: 13,
    background: C.bg,
    border: `2px solid ${C.border}`,
    borderRadius: 14,
    boxShadow: `4px 4px 0 0 ${C.border}`,
    overflow: 'hidden',
    zIndex: 999999,
    position: 'fixed',
    top: 16,
    right: 16,
    pointerEvents: 'auto',
  },
  header: {
    display: 'flex', alignItems: 'center', gap: 6,
    padding: '10px 14px', background: C.ink,
    color: '#fff', cursor: 'grab', userSelect: 'none',
  },
  dragHandle: { color: '#475569', fontSize: 12, lineHeight: 1 },
  headerTitle: { flex: 1, fontWeight: 800, fontSize: 13, letterSpacing: 0.3 },
  closeBtn: { background: 'none', border: 'none', color: '#94a3b8', fontSize: 18, cursor: 'pointer', lineHeight: 1, padding: 0 },
  urlBar: {
    display: 'flex', alignItems: 'center', gap: 6,
    padding: '5px 14px', background: '#f5f6fc',
    borderBottom: `1px solid ${C.border}`,
  },
  urlBarLabel: { fontSize: 10, fontWeight: 700, color: C.muted, textTransform: 'uppercase' as const, letterSpacing: 0.5, flexShrink: 0 },
  urlBarValue: { fontSize: 11, color: C.muted, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' as const },
  body: { padding: '14px 14px 10px' },
  loadingRow: { display: 'flex', alignItems: 'center', gap: 10, marginBottom: 6 },
  spinner: {
    width: 18, height: 18, borderRadius: '50%',
    border: `2px solid ${C.border}`, borderTopColor: C.primary,
    flexShrink: 0,
  },
  loadingText: { fontWeight: 700, color: C.foreground, fontSize: 13 },
  errorBox: { display: 'flex', alignItems: 'flex-start', gap: 8, padding: '10px 12px', background: '#fef2f2', borderRadius: 8, border: `2px solid #fecaca`, marginBottom: 10 },
  errorIcon: { fontSize: 16, flexShrink: 0 },
  errorText: { color: '#991b1b', margin: 0, fontSize: 12, lineHeight: 1.4 },
  gaugeSection: { marginBottom: 12 },
  gaugeHeader: { display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 6 },
  gaugeLabel: { fontSize: 10, fontWeight: 700, color: C.muted, textTransform: 'uppercase' as const, letterSpacing: 0.5 },
  gaugeRight: { display: 'flex', alignItems: 'center', gap: 6 },
  gaugeScore: { fontSize: 22, fontWeight: 800, lineHeight: 1, fontFamily: 'monospace' },
  gaugeBadge: { fontSize: 10, fontWeight: 800, padding: '2px 8px', borderRadius: 999, textTransform: 'uppercase' as const, letterSpacing: 0.4, border: '1px solid' },
  gaugeTrack: { height: 6, background: C.border, borderRadius: 999, overflow: 'hidden' },
  gaugeFill: { height: '100%', borderRadius: 999, transition: 'width 0.5s ease' },
  confidenceText: { fontSize: 10, color: C.muted, margin: '4px 0 0 0' },
  verdictBox: { display: 'flex', alignItems: 'flex-start', gap: 8, padding: '8px 10px', borderRadius: 8, border: '2px solid', marginBottom: 10 },
  verdictIcon: { fontSize: 14, flexShrink: 0, marginTop: 1 },
  verdictText: { margin: 0, fontWeight: 700, fontSize: 12, lineHeight: 1.4 },
  chipsSection: { marginBottom: 10 },
  sectionLabel: { fontSize: 9, fontWeight: 800, color: C.muted, letterSpacing: 0.7, textTransform: 'uppercase' as const, margin: '0 0 5px 0' },
  chipsRow: { display: 'flex', flexWrap: 'wrap' as const, gap: 4 },
  chip: { background: '#fff8e1', color: '#78350f', padding: '3px 9px', borderRadius: 999, fontSize: 11, fontWeight: 600, border: '1px solid #fde68a' },
  reasonSection: { marginBottom: 12 },
  reasonText: { margin: 0, color: C.foreground, fontSize: 12, lineHeight: 1.5 },
  moreDetailsBtn: {
    display: 'flex', justifyContent: 'space-between', alignItems: 'center',
    width: '100%', padding: '8px 12px', marginBottom: 8,
    borderRadius: 8, border: `2px solid ${C.primary}`,
    background: '#ede9fe', color: C.primaryDark,
    fontSize: 12, fontWeight: 800,
    cursor: 'pointer', boxSizing: 'border-box' as const,
    boxShadow: `2px 2px 0 0 ${C.primary}`,
  },
  moreDetailsArrow: { fontSize: 14 },
  actionRow: { display: 'flex', gap: 5 },
  actionBtn: {
    flex: 1, padding: '6px 8px',
    border: `2px solid ${C.border}`,
    borderRadius: 7, background: '#f5f6fc',
    cursor: 'pointer', fontSize: 11, fontWeight: 600, color: C.foreground,
  },
  flagRow: { display: 'flex' },
  flagBtn: {
    flex: 1,
    display: 'flex', alignItems: 'center', justifyContent: 'space-between',
    gap: 8, padding: '7px 12px',
    border: `2px solid #fca5a5`,
    borderRadius: 7, background: '#fff1f1',
    cursor: 'pointer', fontSize: 12, fontWeight: 700, color: C.destructive,
    boxShadow: `2px 2px 0 0 #fca5a5`,
  },
  flagBtnDone: { borderColor: '#86efac', color: C.secondary, background: '#f0fdf4', boxShadow: `2px 2px 0 0 #86efac` },
  flagCountBadge: {
    fontSize: 10, fontWeight: 800,
    padding: '2px 8px', borderRadius: 999,
    background: '#fca5a5', color: '#7f1d1d',
    whiteSpace: 'nowrap' as const,
  },
  safeBtn: { background: C.secondary, color: '#fff', border: 'none', fontWeight: 800, boxShadow: `2px 2px 0 0 #078a5a` },
  cautionBtn: { background: '#fff', color: C.destructive, border: `2px solid #fca5a5`, fontSize: 11 },
  flagNote: { color: C.secondary, fontSize: 10, margin: '6px 0 0 0', textAlign: 'center' as const },
  flagNoteError: { color: C.destructive, fontSize: 10, margin: '6px 0 0 0', textAlign: 'center' as const },
};
