-- Run this once against your Supabase project:
--   npx supabase db push
-- or paste it into the SQL Editor in the Supabase dashboard.

create table if not exists public.flags (
  id uuid primary key default gen_random_uuid(),
  created_at timestamptz not null default now(),
  post_url text not null,
  snippet text,
  ai_probability integer not null default 50,
  bias_flags text[] not null default '{}',
  reasoning text
);

create index if not exists flags_created_at_idx on public.flags (created_at desc);

alter table public.flags enable row level security;

-- The extension writes flags using the public anon key, so anon needs
-- insert access. There's no auth in v1, so anyone with the key could in
-- theory insert junk rows — acceptable for an MVP, but add auth/rate
-- limiting before this goes public.
create policy "Anyone can insert flags"
  on public.flags
  for insert
  to anon
  with check (true);

-- The dashboard page also reads with the anon key. This makes the flag
-- board effectively public (anyone with the key can read it, same as
-- anyone who has the extension installed). Tighten this if you want the
-- dashboard to require login instead.
create policy "Anyone can read flags"
  on public.flags
  for select
  to anon
  using (true);
