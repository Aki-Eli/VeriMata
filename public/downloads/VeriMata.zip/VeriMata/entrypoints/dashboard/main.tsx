import React from 'react';
import ReactDOM from 'react-dom/client';
import Dashboard from './Dashboard';

const root = document.getElementById('root') ?? document.createElement('div');
if (!root.isConnected) document.body.appendChild(root);
ReactDOM.createRoot(root).render(<Dashboard />);
