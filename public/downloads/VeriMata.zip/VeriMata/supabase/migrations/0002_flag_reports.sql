-- Migration: restructure flags into url registry + per-user reports
-- Run in Supabase SQL Editor or via: npx supabase db push

-- 1. Add user_id tracking and flag count to the existing flags table
--    (flags = one row per unique URL/content, acts as registry)
ALTER TABLE public.flags
  ADD COLUMN IF NOT EXISTS flag_count integer NOT NULL DEFAULT 0;

-- 2. Per-user flag reports — one row per user action
CREATE TABLE IF NOT EXISTS public.flag_reports (
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  created_at    timestamptz NOT NULL DEFAULT now(),
  flag_id       uuid NOT NULL REFERENCES public.flags(id) ON DELETE CASCADE,
  user_id       uuid,                      -- null = anonymous / not signed in
  user_email    text,                      -- optional display name
  reason        text NOT NULL,             -- user's reason for flagging
  category      text                       -- e.g. 'misinformation', 'ai_generated', 'spam', 'other'
);

CREATE INDEX IF NOT EXISTS flag_reports_flag_id_idx ON public.flag_reports (flag_id);
CREATE INDEX IF NOT EXISTS flag_reports_user_id_idx ON public.flag_reports (user_id);

ALTER TABLE public.flag_reports ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can insert flag_reports"
  ON public.flag_reports FOR INSERT TO anon WITH CHECK (true);

CREATE POLICY "Anyone can read flag_reports"
  ON public.flag_reports FOR SELECT TO anon USING (true);

-- 3. Trigger: keep flags.flag_count in sync automatically
CREATE OR REPLACE FUNCTION public.sync_flag_count()
RETURNS TRIGGER LANGUAGE plpgsql AS $$
BEGIN
  IF TG_OP = 'INSERT' THEN
    UPDATE public.flags SET flag_count = flag_count + 1 WHERE id = NEW.flag_id;
  ELSIF TG_OP = 'DELETE' THEN
    UPDATE public.flags SET flag_count = GREATEST(0, flag_count - 1) WHERE id = OLD.flag_id;
  END IF;
  RETURN NULL;
END;
$$;

DROP TRIGGER IF EXISTS trg_sync_flag_count ON public.flag_reports;
CREATE TRIGGER trg_sync_flag_count
  AFTER INSERT OR DELETE ON public.flag_reports
  FOR EACH ROW EXECUTE FUNCTION public.sync_flag_count();

-- 4. Allow delete on flags so the cleanup function can remove empty entries
CREATE POLICY "Anyone can delete flags"
  ON public.flags FOR DELETE TO anon USING (flag_count = 0);
