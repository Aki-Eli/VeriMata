import React, { useState, useEffect } from 'react';
import { supabase } from '../../lib/supabase';
import type { User } from '@supabase/supabase-js';

const C = {
  bg: '#f5f6fc',
  card: '#ffffff',
  foreground: '#191c3a',
  muted: '#666b93',
  border: '#dfe1f4',
  primary: '#5b46f0',
  primaryDark: '#4835d4',
  secondary: '#0aa66e',
  accent: '#ffb422',
  destructive: '#e6473d',
  ink: '#191c3a',
};

// SVG icons — no emojis
const IconShield = () => (
  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
    <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/>
  </svg>
);
const IconSearch = () => (
  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
    <circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/>
  </svg>
);
const IconMouse = () => (
  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <rect x="5" y="2" width="14" height="20" rx="7"/><line x1="12" y1="2" x2="12" y2="10"/>
  </svg>
);
const IconClick = () => (
  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <path d="M9 9l11 2.5-6.5 2-2 6.5L9 9z"/><path d="M7.2 2.2L8 5"/><path d="M5 7.2L2.2 8"/><path d="M14 4.1L12 6"/><path d="M4.1 14L6 12"/>
  </svg>
);
const IconCheck = () => (
  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round">
    <polyline points="20 6 9 17 4 12"/>
  </svg>
);
const IconLightbulb = () => (
  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <path d="M9 21h6"/><path d="M12 2a7 7 0 0 1 5 11.9c-.6.6-1 1.4-1 2.1H8c0-.7-.4-1.5-1-2.1A7 7 0 0 1 12 2z"/>
  </svg>
);
const IconExternalLink = () => (
  <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
    <path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"/><polyline points="15 3 21 3 21 9"/><line x1="10" y1="14" x2="21" y2="3"/>
  </svg>
);
const IconAlert = () => (
  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
    <path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/>
  </svg>
);

type AuthState = { status: 'checking' } | { status: 'signed-out' } | { status: 'signed-in'; user: User };

export default function Popup() {
  const logoUrl = browser.runtime.getURL('images/logo.png');
  const [authState, setAuthState] = useState<AuthState>({ status: 'checking' });
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [authMode, setAuthMode] = useState<'signin' | 'signup'>('signin');
  const [username, setUsername] = useState('');
  const [authError, setAuthError] = useState('');
  const [authLoading, setAuthLoading] = useState(false);
  const [link, setLink] = useState('');
  const [scanState, setScanState] = useState<'idle' | 'loading' | 'done' | 'error'>('idle');
  const [scanResult, setScanResult] = useState<any>(null);
  const [scanError, setScanError] = useState('');

  useEffect(() => {
    // Option A: try to grab session from an open website tab first
    // Option C fallback: restore from chrome.storage, then manual login

    async function init() {
      // 1. Try syncing from the website tab (if open)
      try {
        await browser.runtime.sendMessage({ type: 'SYNC_WEBSITE_SESSION' });
      } catch { /* no tab open, continue */ }

      // 2. Try restoring from storage (sync above may have just written it)
      const stored = await chrome.storage.local.get(['sb_full_session', 'sb_session']);
      const full = stored?.sb_full_session;

      if (full?.access_token && full?.refresh_token) {
        const { data, error } = await supabase.auth.setSession({
          access_token: full.access_token,
          refresh_token: full.refresh_token,
        });
        if (!error && data.session?.user) {
          // onAuthStateChange will set signed-in — don't set signed-out here
          return;
        }
      }

      // 3. Nothing worked — show login form
      setAuthState({ status: 'signed-out' });
    }

    init();

    // Keep storage in sync whenever session changes (login, auto-refresh, logout)
    const { data: listener } = supabase.auth.onAuthStateChange((_event, session) => {
      if (session?.user) {
        setAuthState({ status: 'signed-in', user: session.user });
        chrome.storage.local.set({
          sb_full_session: {
            access_token: session.access_token,
            refresh_token: session.refresh_token,
          },
          sb_session: { access_token: session.access_token },
        });
      } else {
        setAuthState({ status: 'signed-out' });
        chrome.storage.local.remove(['sb_full_session', 'sb_session']);
      }
    });

    return () => listener.subscription.unsubscribe();
  }, []);

  const handleSignIn = async (e: React.FormEvent) => {
    e.preventDefault(); setAuthError(''); setAuthLoading(true);
    try { const { error } = await supabase.auth.signInWithPassword({ email, password }); if (error) throw error; }
    catch (err: any) { setAuthError(err.message || 'Sign in failed'); }
    finally { setAuthLoading(false); }
  };

  const handleSignUp = async (e: React.FormEvent) => {
    e.preventDefault(); setAuthError(''); setAuthLoading(true);
    try {
      const { error } = await supabase.auth.signUp({ email, password, options: { data: { username } } });
      if (error) throw error;
      setAuthError('Check your email to confirm, then sign in.'); setAuthMode('signin');
    } catch (err: any) { setAuthError(err.message || 'Sign up failed'); }
    finally { setAuthLoading(false); }
  };

  const handleSignOut = async () => { await supabase.auth.signOut(); setLink(''); setScanState('idle'); setScanResult(null); };

  const handleScan = async () => {
    const trimmed = link.trim(); if (!trimmed) return;
    setScanState('loading'); setScanResult(null); setScanError('');
    try {
      const response = await browser.runtime.sendMessage({ type: 'REQUEST_ANALYSIS', text: trimmed, pageUrl: trimmed });
      if (response?.ok) { setScanResult(response.result); setScanState('done'); }
      else { setScanError(response?.error ?? 'Analysis failed'); setScanState('error'); }
    } catch (err: any) { setScanError(err.message ?? 'Something went wrong'); setScanState('error'); }
  };

  const openWebApp = () => chrome.tabs.create({ url: 'https://veri-mata.vercel.app/dashboard/analyzer?from=extension' });

  if (authState.status === 'checking') {
    return (
      <div style={s.page}>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', padding: 32, gap: 10 }}>
          <div style={s.spinnerPrimary} />
          <span style={{ color: C.muted, fontSize: 13 }}>Loading…</span>
        </div>
      </div>
    );
  }

  if (authState.status === 'signed-out') {
    return (
      <div style={s.page}>
        <div style={s.header}>
          <img src={logoUrl} style={s.logoImg} alt="VeriMata" />
          <div>
            <div style={s.appName}>VeriMata</div>
            <div style={s.appSub}>AI Content Detector</div>
          </div>
        </div>
        <div style={s.divider} />
        <div style={s.section}>
          <p style={s.sectionTitle}>{authMode === 'signin' ? 'Sign in to continue' : 'Create an account'}</p>
          <form onSubmit={authMode === 'signin' ? handleSignIn : handleSignUp} style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
            {authMode === 'signup' && (
              <input type="text" placeholder="Username" value={username} onChange={e => setUsername(e.target.value)} required minLength={3} style={s.input} />
            )}
            <input type="email" placeholder="Email address" value={email} onChange={e => setEmail(e.target.value)} required style={s.input} />
            <input type="password" placeholder="Password" value={password} onChange={e => setPassword(e.target.value)} required minLength={6} style={s.input} />
            {authError && (
              <div style={{ ...s.alert, ...(authError.includes('Check') ? s.alertOk : s.alertErr) }}>{authError}</div>
            )}
            <button type="submit" disabled={authLoading} style={s.primaryBtn}>
              {authLoading ? '…' : authMode === 'signin' ? 'Sign In' : 'Create Account'}
            </button>
          </form>
          <button onClick={() => { setAuthMode(authMode === 'signin' ? 'signup' : 'signin'); setAuthError(''); }} style={s.linkBtn}>
            {authMode === 'signin' ? "Don't have an account? Sign up" : 'Already have an account? Sign in'}
          </button>
        </div>
      </div>
    );
  }

  const score = scanResult?.aiProbability ?? 0;
  const scoreColor = score >= 70 ? C.destructive : score >= 40 ? C.accent : C.secondary;
  const hasFactuality = scanResult?.factualityScore != null;
  const fscore = scanResult?.factualityScore ?? 0;
  const fColor = fscore >= 60 ? C.secondary : fscore >= 35 ? C.accent : C.destructive;

  const steps = [
    { icon: <IconSearch />, text: <><strong>Select any text</strong> on a webpage</> },
    { icon: <IconMouse />, text: <><strong>Right-click</strong> the selection</> },
    { icon: <IconClick />, text: <>Click <strong>"Analyze with VeriMata"</strong></> },
    { icon: <IconCheck />, text: <>Results appear as an overlay card</>, done: true },
  ];

  return (
    <div style={s.page}>
      <div style={s.header}>
        <img src={logoUrl} style={s.logoImg} alt="VeriMata" />
        <div style={{ flex: 1 }}>
          <div style={s.appName}>VeriMata</div>
          <div style={s.appSub}>{authState.user.email}</div>
        </div>
        <button onClick={handleSignOut} style={s.ghostBtn}>Sign out</button>
      </div>

      <div style={s.divider} />

      {/* How to scan */}
      <div style={s.section}>
        <p style={s.sectionTitle}>How to analyze content</p>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 4 }}>
          {steps.map((step, i) => (
            <div key={i}>
              <div style={s.step}>
                <div style={{ ...s.stepIcon, background: step.done ? C.secondary : C.ink, color: '#fff' }}>
                  {step.icon}
                </div>
                <div style={{ fontSize: 12, color: C.foreground, lineHeight: 1.4 }}>{step.text}</div>
              </div>
              {i < 3 && <div style={{ textAlign: 'center', color: C.border, fontSize: 12, lineHeight: '8px' }}>↓</div>}
            </div>
          ))}
        </div>
        <div style={s.tipBox}>
          <span style={{ color: C.accent, flexShrink: 0 }}><IconLightbulb /></span>
          <span style={{ fontSize: 11, color: '#78350f', lineHeight: 1.4 }}>Also works on images and videos — right-click directly on them</span>
        </div>
      </div>

      <div style={s.divider} />

      {/* Link scanner */}
      <div style={s.section}>
        <p style={s.sectionTitle}>Or paste a link to check</p>
        <p style={{ fontSize: 11, color: C.muted, margin: '-6px 0 8px 0' }}>Check any URL for phishing or scam patterns</p>
        <div style={{ display: 'flex', gap: 6 }}>
          <input
            type="text" value={link} placeholder="https://example.com/post"
            onChange={e => { setLink(e.target.value); setScanState('idle'); setScanResult(null); }}
            onKeyDown={e => e.key === 'Enter' && handleScan()}
            style={{ ...s.input, flex: 1, marginBottom: 0 }}
          />
          <button
            onClick={handleScan} disabled={!link.trim() || scanState === 'loading'}
            style={{ ...s.primaryBtn, width: 'auto', padding: '0 14px', flexShrink: 0, opacity: (!link.trim() || scanState === 'loading') ? 0.6 : 1 }}
          >
            {scanState === 'loading' ? <div style={s.spinnerWhite} /> : 'Scan'}
          </button>
        </div>

        {scanState === 'error' && <div style={{ ...s.alert, ...s.alertErr, marginTop: 8 }}>{scanError}</div>}

        {scanState === 'done' && scanResult && (
          <div style={s.resultCard}>
            {/* AI score */}
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 6 }}>
              <span style={{ fontSize: 10, fontWeight: 700, color: C.muted, textTransform: 'uppercase', letterSpacing: 0.5 }}>AI Likelihood</span>
              <span style={{ fontSize: 22, fontWeight: 800, color: scoreColor, fontFamily: 'monospace' }}>{score}%</span>
            </div>
            <div style={{ height: 5, background: C.border, borderRadius: 999, overflow: 'hidden', marginBottom: 8 }}>
              <div style={{ height: '100%', width: `${score}%`, background: scoreColor, borderRadius: 999 }} />
            </div>

            {/* Factuality score — only when present */}
            {hasFactuality && (
              <>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 4, marginTop: 8 }}>
                  <span style={{ fontSize: 10, fontWeight: 700, color: C.muted, textTransform: 'uppercase', letterSpacing: 0.5 }}>Factuality</span>
                  <span style={{ fontSize: 18, fontWeight: 800, color: fColor, fontFamily: 'monospace' }}>{fscore}%</span>
                </div>
                <div style={{ height: 5, background: C.border, borderRadius: 999, overflow: 'hidden', marginBottom: 8 }}>
                  <div style={{ height: '100%', width: `${fscore}%`, background: fColor, borderRadius: 999 }} />
                </div>
              </>
            )}

            {/* Verdict */}
            <div style={{ padding: '7px 10px', borderRadius: 8, border: `2px solid ${scoreColor}33`, background: `${scoreColor}0d`, marginBottom: 8, display: 'flex', alignItems: 'center', gap: 6 }}>
              <span style={{ color: scoreColor, flexShrink: 0 }}>
                {score >= 70 ? <IconAlert /> : <IconCheck />}
              </span>
              <span style={{ color: scoreColor, fontWeight: 700, fontSize: 12 }}>
                {scanResult.shortVerdict ?? (score >= 70 ? 'Looks risky' : score >= 40 ? 'Uncertain' : 'Looks safe')}
              </span>
            </div>

            {/* Chips */}
            {(scanResult.chips ?? scanResult.biasFlags ?? []).length > 0 && (
              <div style={{ display: 'flex', flexWrap: 'wrap', gap: 4, marginBottom: 8 }}>
                {(scanResult.chips ?? scanResult.biasFlags).map((c: string, i: number) => (
                  <span key={i} style={s.chip}>{c}</span>
                ))}
              </div>
            )}

            {/* Reason */}
            {(scanResult.reason || scanResult.reasoning) && (
              <p style={{ fontSize: 11, color: C.muted, lineHeight: 1.5, margin: '0 0 10px 0' }}>
                {scanResult.reason ?? scanResult.reasoning}
              </p>
            )}

            {/* More details */}
            <button onClick={openWebApp} style={s.moreBtn}>
              <span style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
                <IconSearch />
                Full Deep Analysis
              </span>
              <IconExternalLink />
            </button>
          </div>
        )}
      </div>

      <div style={s.divider} />

      <div style={{ padding: '10px 16px' }}>
        <button onClick={openWebApp} style={{ ...s.ghostBtn, width: '100%', padding: '8px 0', borderRadius: 8, fontSize: 11, fontWeight: 600, display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 6 }}>
          <IconExternalLink />
          Open VeriMata Dashboard
        </button>
      </div>
    </div>
  );
}

const s: Record<string, React.CSSProperties> = {
  page: { width: 340, fontFamily: 'system-ui, -apple-system, sans-serif', background: C.bg, color: C.foreground, fontSize: 13, boxSizing: 'border-box' },
  header: { display: 'flex', alignItems: 'center', gap: 10, padding: '14px 16px', background: C.ink },
  logoImg: { width: 36, height: 36, borderRadius: 10, objectFit: 'contain', flexShrink: 0 },
  appName: { fontWeight: 800, fontSize: 15, color: '#fff', letterSpacing: 0.3 },
  appSub: { fontSize: 10, color: '#94a3b8', marginTop: 1 },
  ghostBtn: { background: 'transparent', border: '1px solid #334155', color: '#94a3b8', fontSize: 10, padding: '4px 10px', borderRadius: 6, cursor: 'pointer', flexShrink: 0 },
  divider: { height: 1, background: C.border },
  section: { padding: '14px 16px' },
  sectionTitle: { fontWeight: 800, fontSize: 11, color: C.foreground, margin: '0 0 10px 0', textTransform: 'uppercase', letterSpacing: 0.6 },
  input: { width: '100%', boxSizing: 'border-box', padding: '9px 11px', fontSize: 12, borderRadius: 8, border: `2px solid ${C.border}`, outline: 'none', color: C.foreground, background: C.card, marginBottom: 0 },
  primaryBtn: { width: '100%', padding: '9px 0', borderRadius: 8, border: 'none', background: C.primary, color: '#fff', fontSize: 13, fontWeight: 800, cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center', boxShadow: `3px 3px 0 0 ${C.primaryDark}`, boxSizing: 'border-box' },
  linkBtn: { marginTop: 10, background: 'none', border: 'none', color: C.primary, fontSize: 11, cursor: 'pointer', padding: 0, textDecoration: 'underline', width: '100%', textAlign: 'center' },
  alert: { padding: '8px 10px', borderRadius: 7, fontSize: 11, lineHeight: 1.4, border: '2px solid' },
  alertErr: { background: '#fef2f2', color: '#991b1b', borderColor: '#fecaca' },
  alertOk: { background: '#f0fdf4', color: '#166534', borderColor: '#bbf7d0' },
  step: { display: 'flex', alignItems: 'flex-start', gap: 10, padding: '8px 10px', background: C.card, borderRadius: 8, border: `2px solid ${C.border}`, boxShadow: `2px 2px 0 0 ${C.border}` },
  stepIcon: { width: 24, height: 24, borderRadius: '50%', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0, marginTop: 1 },
  tipBox: { display: 'flex', alignItems: 'flex-start', gap: 7, marginTop: 10, padding: '8px 10px', background: '#fffbeb', borderRadius: 7, border: '2px solid #fde68a', boxShadow: '2px 2px 0 0 #fde68a' },
  resultCard: { marginTop: 10, padding: 12, background: C.card, borderRadius: 10, border: `2px solid ${C.border}`, boxShadow: `3px 3px 0 0 ${C.border}` },
  chip: { background: '#fff8e1', color: '#78350f', padding: '2px 8px', borderRadius: 999, fontSize: 10, fontWeight: 600, border: '1px solid #fde68a' },
  moreBtn: { width: '100%', padding: '7px 12px', borderRadius: 7, border: `2px solid ${C.primary}`, background: '#ede9fe', color: C.primaryDark, fontSize: 11, fontWeight: 800, cursor: 'pointer', boxSizing: 'border-box', boxShadow: `2px 2px 0 0 ${C.primary}`, display: 'flex', alignItems: 'center', justifyContent: 'space-between' },
  spinnerPrimary: { width: 18, height: 18, borderRadius: '50%', border: `2px solid ${C.border}`, borderTopColor: C.primary, animation: 'spin 0.7s linear infinite' },
  spinnerWhite: { width: 14, height: 14, borderRadius: '50%', border: '2px solid rgba(255,255,255,0.4)', borderTopColor: '#fff', animation: 'spin 0.7s linear infinite' },
};
