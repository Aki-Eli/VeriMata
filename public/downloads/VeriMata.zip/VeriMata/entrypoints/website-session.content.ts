// Content script that runs on veri-mata.vercel.app only.
// When the popup asks for the session, this reads Supabase's localStorage
// entry from the website's context (same origin = allowed) and returns it.

export default defineContentScript({
  matches: ['https://veri-mata.vercel.app/*'],
  runAt: 'document_idle',
  main() {
    browser.runtime.onMessage.addListener((message, _sender, sendResponse) => {
      if (message.type !== 'GET_WEBSITE_SESSION') return;

      try {
        // Supabase stores the session under a key like:
        // sb-<project-ref>-auth-token
        // Find it by scanning localStorage for the sb-*-auth-token pattern.
        let session: { access_token: string; refresh_token: string } | null = null;

        for (let i = 0; i < localStorage.length; i++) {
          const key = localStorage.key(i);
          if (key && /^sb-.+-auth-token$/.test(key)) {
            try {
              const raw = localStorage.getItem(key);
              if (raw) {
                const parsed = JSON.parse(raw);
                // Supabase v2 stores it directly, v1 wraps in currentSession
                const s = parsed?.access_token ? parsed : parsed?.currentSession;
                if (s?.access_token && s?.refresh_token) {
                  session = { access_token: s.access_token, refresh_token: s.refresh_token };
                  break;
                }
              }
            } catch { /* malformed entry, skip */ }
          }
        }

        sendResponse({ ok: true, session });
      } catch (err) {
        sendResponse({ ok: false, session: null });
      }

      return true; // keep channel open for async sendResponse
    });
  },
});
